# Databricks notebook source
# DBTITLE 1,Day 3 Lab Overview
# MAGIC %md
# MAGIC # Day 3 Lab Exercises: DevOps, Optimization, Advanced Modelling & Data Quality
# MAGIC
# MAGIC Hands-on practice for Day 3 of the **Databricks Data Modelling for CPG** programme. SnackCo's star schema is going to production. You will define its deployment as code, add automated data quality tests, tune the physical layout of a slow fact table, and fix a many-to-many double-counting problem.
# MAGIC
# MAGIC | # | Exercise | Day 3 module | Time |
# MAGIC |---|---|---|---|
# MAGIC | 3.1 | Author a Declarative Automation Bundle (`databricks.yml`) with dev and prod targets | 3.1 Git, CI/CD & DABs | 25 min |
# MAGIC | 3.2 | Data quality constraints and an automated test suite | 3.1 Testing / 3.4 Data Quality | 25 min |
# MAGIC | 3.3 | Liquid Clustering and OPTIMIZE on a small-file fact table | 3.3 Physical Model Optimization | 20 min |
# MAGIC | 3.4 | Bridge table with weights, and schema evolution | 3.4 Advanced Modelling | 30 min |
# MAGIC | SC | Self-Check: automated validation of all 4 exercises | All | 5 min |
# MAGIC
# MAGIC **Total: about 105 minutes.**
# MAGIC
# MAGIC ### How to work through this lab
# MAGIC 1. Set your catalog and schema in **Lab Configuration** and run it.
# MAGIC 2. Run **Lab Setup** once (about 1 minute). It writes the fact table in 20 small batches on purpose, so it starts with many small files, then injects known data quality issues.
# MAGIC 3. Do the exercises in order. Exercise 3.1 is written in Python (a YAML string); 3.2 to 3.4 are SQL.
# MAGIC 4. A reference solution is folded at the end of each documentation cell.
# MAGIC 5. Run **Self-Check** at the end.
# MAGIC
# MAGIC ### Source data created by the setup
# MAGIC | Table | Description | Rows |
# MAGIC |---|---|---|
# MAGIC | `lx3_dim_product` | Product dimension (product_key 1 to 12) | 12 |
# MAGIC | `lx3_dim_promotion` | Promotions P01 to P04 | 4 |
# MAGIC | `lx3_promo_map` | Which products are in which promotions (some products are in 2 promotions) | 10 |
# MAGIC | `lx3_fact_sales` | POS fact written in 20+ small batches, with **5 orphan product keys, 3 duplicated transactions and 2 missing retailer IDs** injected | 5,010 |
# MAGIC | `lx3_baseline` | File count of `lx3_fact_sales` before optimization | 1 |

# COMMAND ----------

# DBTITLE 1,Lab Configuration
# Set your own catalog and schema here, then run this cell.
CATALOG = "lakemeter_catalog"
SCHEMA = "labuser3"

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Working in {CATALOG}.{SCHEMA}. All lab objects use the prefix lx3_")

# COMMAND ----------

# DBTITLE 1,Lab Setup - Create Source Data
# Creates the Day 3 source tables and resets your exercise objects. Safe to re-run (about 1 minute).

spark.sql("""CREATE OR REPLACE TABLE lx3_dim_product AS SELECT * FROM VALUES
  (1,'SKU001','Maggi'),(2,'SKU002','Maggi'),(3,'SKU003','Lays'),(4,'SKU004','Lays'),(5,'SKU005','Kurkure'),(6,'SKU006','Tropicana'),
  (7,'SKU007','Tropicana'),(8,'SKU008','Dove'),(9,'SKU009','Surf Excel'),(10,'SKU010','Parle-G'),(11,'SKU011','Amul'),(12,'SKU012','Amul')
  AS t(product_key, sku, brand)""")
spark.sql("""CREATE OR REPLACE TABLE lx3_dim_promotion AS SELECT * FROM VALUES
  ('P01','Diwali Dhamaka'),('P02','Buy 2 Get 1'),('P03','Monsoon Munchies'),('P04','Summer Coolers')
  AS t(promo_id, promo_name)""")
spark.sql("""CREATE OR REPLACE TABLE lx3_promo_map AS SELECT * FROM VALUES
  (1,'P01'),(1,'P02'),(2,'P01'),(3,'P02'),(3,'P03'),(4,'P03'),(5,'P03'),(6,'P04'),(6,'P01'),(7,'P04')
  AS t(product_key, promo_id)""")

# Reset exercise objects
for obj in ["TABLE lx3_fact_sales", "TABLE lx3_dq_results", "TABLE lx3_bridge_product_promo", "VIEW lx3_v_promo_revenue"]:
    spark.sql(f"DROP {obj.split()[0]} IF EXISTS {obj.split()[1]}")

# Fact table written in 20 small batches, with auto-compaction off, so it starts with many small files
spark.sql("""CREATE TABLE lx3_fact_sales (txn_id BIGINT, txn_date DATE, product_key INT, retailer_id STRING,
  region STRING, channel STRING, qty INT, net_sales DECIMAL(12,2))
  TBLPROPERTIES ('delta.autoOptimize.autoCompact' = 'false', 'delta.autoOptimize.optimizeWrite' = 'false')""")
for b in range(20):
    spark.sql(f"""INSERT INTO lx3_fact_sales
      SELECT id + 700000, date_add(DATE'2026-01-01', CAST(pmod(hash(id,'dt'),181) AS INT)),
        CAST(pmod(hash(id,'p'),12) + 1 AS INT), concat('R0', CAST(pmod(hash(id,'r'),8)+1 AS STRING)),
        element_at(array('North','South','East','West'), pmod(hash(id,'g'),4)+1),
        element_at(array('Modern Trade','General Trade','E-Commerce'), pmod(hash(id,'c'),3)+1),
        CAST(pmod(hash(id,'q'),20)+1 AS INT), CAST(10 + pmod(hash(id,'n'),2000) AS DECIMAL(12,2))
      FROM range({b * 250}, {(b + 1) * 250})""")

# Inject known data quality issues: 5 orphan product keys, 3 duplicated transactions, 2 missing retailer IDs
spark.sql("INSERT INTO lx3_fact_sales SELECT 799000 + id, DATE'2026-03-15', 99, 'R01', 'West', 'Modern Trade', 5, 500.00 FROM range(5)")
spark.sql("INSERT INTO lx3_fact_sales SELECT * FROM lx3_fact_sales WHERE txn_id IN (700001, 700002, 700003)")
spark.sql("INSERT INTO lx3_fact_sales SELECT 799100 + id, DATE'2026-04-01', 4, NULL, 'North', 'General Trade', 3, 90.00 FROM range(2)")

num_files = spark.sql("DESCRIBE DETAIL lx3_fact_sales").collect()[0]["numFiles"]
spark.sql(f"CREATE OR REPLACE TABLE lx3_baseline AS SELECT 'num_files_before' AS metric, CAST({num_files} AS BIGINT) AS value")

display(spark.sql("""
  SELECT 'lx3_fact_sales' AS table_name, COUNT(*) AS row_count FROM lx3_fact_sales
  UNION ALL SELECT 'lx3_dim_product', COUNT(*) FROM lx3_dim_product
  UNION ALL SELECT 'lx3_promo_map', COUNT(*) FROM lx3_promo_map"""))
print(f"lx3_fact_sales starts with {num_files} files")

# COMMAND ----------

# DBTITLE 1,Exercise 3.1 - Declarative Automation Bundle
# MAGIC %md
# MAGIC ## Exercise 3.1: Author a Declarative Automation Bundle (25 minutes)
# MAGIC
# MAGIC **Objective:** Describe SnackCo's daily load job as code in `databricks.yml`, with separate dev and prod targets that write to different catalogs.
# MAGIC
# MAGIC **Business scenario:** Engineers currently edit catalog names by hand before every prod deployment. Last week someone forgot, and test data was written into the prod catalog. The platform lead wants one bundle in Git that deploys the same job to dev and prod, where only the target decides the catalog.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A bundle is defined in `databricks.yml`: `bundle` (name), `variables`, `resources` (jobs, pipelines, ...) and `targets` (dev, prod, ...).
# MAGIC * **Variables** are referenced as `${var.catalog}` and can be overridden per target.
# MAGIC * `mode: development` prefixes resources with your user name and pauses schedules; `mode: production` enforces production safeguards.
# MAGIC * Task dependencies use `depends_on: [{task_key: ...}]`.
# MAGIC * CLI workflow: `databricks bundle validate`, then `databricks bundle deploy -t dev`, then `databricks bundle run -t dev cpg_daily_load`.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. In the next cell, complete the `BUNDLE_YML` string:
# MAGIC    * Give the bundle a real name (for example `snackco_cpg_model`).
# MAGIC    * Set the default of variable `catalog` to `dev_catalog`.
# MAGIC    * Add a second task `build_gold` that **depends on** `load_silver` and also passes `catalog: ${var.catalog}`.
# MAGIC    * In target `dev`, override `catalog` to `dev_catalog`.
# MAGIC    * Add a target `prod` with `mode: production` and `catalog` set to `prod_catalog`.
# MAGIC 2. Run the cell. It parses the YAML and prints the structure, so syntax errors show up immediately.
# MAGIC 3. Optional: save the content as `databricks.yml` in a Git folder and run `databricks bundle validate` from the web terminal.
# MAGIC
# MAGIC **Expected result:** Valid YAML with 2 targets, 2 tasks (with a dependency), and no hard-coded catalog names inside the job.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```yaml
# MAGIC bundle:
# MAGIC   name: snackco_cpg_model
# MAGIC
# MAGIC variables:
# MAGIC   catalog:
# MAGIC     description: Target Unity Catalog catalog
# MAGIC     default: dev_catalog
# MAGIC
# MAGIC resources:
# MAGIC   jobs:
# MAGIC     cpg_daily_load:
# MAGIC       name: cpg-daily-load-${bundle.target}
# MAGIC       tasks:
# MAGIC         - task_key: load_silver
# MAGIC           notebook_task:
# MAGIC             notebook_path: ./src/load_silver.ipynb
# MAGIC             base_parameters:
# MAGIC               catalog: ${var.catalog}
# MAGIC         - task_key: build_gold
# MAGIC           depends_on:
# MAGIC             - task_key: load_silver
# MAGIC           notebook_task:
# MAGIC             notebook_path: ./src/build_gold.ipynb
# MAGIC             base_parameters:
# MAGIC               catalog: ${var.catalog}
# MAGIC
# MAGIC targets:
# MAGIC   dev:
# MAGIC     mode: development
# MAGIC     default: true
# MAGIC     variables:
# MAGIC       catalog: dev_catalog
# MAGIC   prod:
# MAGIC     mode: production
# MAGIC     variables:
# MAGIC       catalog: prod_catalog
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 3.1 - Your Work
# Exercise 3.1: complete the TODOs in this YAML, then run the cell.
BUNDLE_YML = """
bundle:
  name: TODO_bundle_name

variables:
  catalog:
    description: Target Unity Catalog catalog
    default: TODO

resources:
  jobs:
    cpg_daily_load:
      name: cpg-daily-load-${bundle.target}
      tasks:
        - task_key: load_silver
          notebook_task:
            notebook_path: ./src/load_silver.ipynb
            base_parameters:
              catalog: ${var.catalog}
        # TODO: add task build_gold that depends_on load_silver and passes catalog: ${var.catalog}

targets:
  dev:
    mode: development
    default: true
    # TODO: override variables -> catalog: dev_catalog
  # TODO: add a prod target with mode: production and catalog: prod_catalog
"""

import yaml, json
parsed = yaml.safe_load(BUNDLE_YML)
print("YAML is valid. Structure:")
print(json.dumps(parsed, indent=2))

# COMMAND ----------

# DBTITLE 1,Exercise 3.2 - Data Quality Constraints and Tests
# MAGIC %md
# MAGIC ## Exercise 3.2: Data Quality Constraints and an Automated Test Suite (25 minutes)
# MAGIC
# MAGIC **Objective:** Protect the fact table with Delta constraints, and write repeatable data quality tests whose results a CI pipeline can use to block a bad deployment.
# MAGIC
# MAGIC **Business scenario:** Last month a broken load pushed negative and orphan rows to prod, and nobody noticed for two days. SnackCo now wants (1) the table itself to reject invalid rows, and (2) a test results table that the CI job checks after every load. The setup has injected real issues into `lx3_fact_sales` for you to find.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * `ALTER TABLE ... ALTER COLUMN ... SET NOT NULL` and `ADD CONSTRAINT name CHECK (condition)` are **enforced** on every future write. They fail if existing rows break the rule.
# MAGIC * Constraints appear in `SHOW TBLPROPERTIES` as `delta.constraints.<name>`.
# MAGIC * Primary and foreign keys in Unity Catalog are **informational only**, so referential integrity must be tested with a query, for example a `LEFT ANTI JOIN`.
# MAGIC * A test suite records `check_name`, `failed_rows` and `status` so it can be automated and audited.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Make `txn_id` NOT NULL.
# MAGIC 2. Add `CONSTRAINT chk_net_sales_non_negative CHECK (net_sales >= 0)`.
# MAGIC 3. Try to insert a row with negative `net_sales` and confirm it is rejected (then remove that statement).
# MAGIC 4. Create `lx3_dq_results` with columns `check_name, failed_rows, status, checked_at` and exactly these 3 checks:
# MAGIC    * `orphan_product_keys`: fact rows whose `product_key` is not in `lx3_dim_product`.
# MAGIC    * `duplicate_txn_ids`: number of `txn_id` values that appear more than once.
# MAGIC    * `null_retailer_ids`: fact rows where `retailer_id` IS NULL.
# MAGIC    * `status` = `'PASS'` when `failed_rows = 0`, otherwise `'FAIL'`.
# MAGIC
# MAGIC **Expected result:** Both constraints exist. The test table shows orphan_product_keys = 5, duplicate_txn_ids = 3, null_retailer_ids = 2, all with status FAIL, which is exactly what the CI gate must catch.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC ALTER TABLE lx3_fact_sales ALTER COLUMN txn_id SET NOT NULL;
# MAGIC ALTER TABLE lx3_fact_sales ADD CONSTRAINT chk_net_sales_non_negative CHECK (net_sales >= 0);
# MAGIC
# MAGIC -- This must fail with a CHECK constraint violation:
# MAGIC -- INSERT INTO lx3_fact_sales VALUES (1, DATE'2026-01-01', 1, 'R01', 'West', 'Modern Trade', 1, -50.00);
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx3_dq_results AS
# MAGIC WITH checks AS (
# MAGIC   SELECT 'orphan_product_keys' AS check_name, COUNT(*) AS failed_rows
# MAGIC   FROM lx3_fact_sales f LEFT ANTI JOIN lx3_dim_product p ON f.product_key = p.product_key
# MAGIC   UNION ALL
# MAGIC   SELECT 'duplicate_txn_ids', COUNT(*)
# MAGIC   FROM (SELECT txn_id FROM lx3_fact_sales GROUP BY txn_id HAVING COUNT(*) > 1)
# MAGIC   UNION ALL
# MAGIC   SELECT 'null_retailer_ids', COUNT(*) FROM lx3_fact_sales WHERE retailer_id IS NULL)
# MAGIC SELECT check_name, failed_rows,
# MAGIC        CASE WHEN failed_rows = 0 THEN 'PASS' ELSE 'FAIL' END AS status,
# MAGIC        current_timestamp() AS checked_at
# MAGIC FROM checks;
# MAGIC
# MAGIC SELECT * FROM lx3_dq_results;
# MAGIC SHOW TBLPROPERTIES lx3_fact_sales;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 3.2 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 3.2: write your SQL below, then run this cell.
# MAGIC -- Step 1: ALTER TABLE lx3_fact_sales ALTER COLUMN txn_id SET NOT NULL
# MAGIC -- Step 2: ALTER TABLE lx3_fact_sales ADD CONSTRAINT chk_net_sales_non_negative CHECK (...)
# MAGIC -- Step 3: try an INSERT with negative net_sales and confirm it fails (then comment it out)
# MAGIC -- Step 4: CREATE OR REPLACE TABLE lx3_dq_results AS WITH checks AS (... 3 checks with UNION ALL ...) SELECT check_name, failed_rows, status, checked_at ...
# MAGIC
# MAGIC SELECT 'Exercise 3.2: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 3.3 - Liquid Clustering and OPTIMIZE
# MAGIC %md
# MAGIC ## Exercise 3.3: Liquid Clustering and OPTIMIZE (20 minutes)
# MAGIC
# MAGIC **Objective:** Fix a small-file problem and lay out the fact table for the filters the business actually uses.
# MAGIC
# MAGIC **Business scenario:** Micro-batch loads have left `lx3_fact_sales` with well over 100 tiny files. Dashboards filter mostly by **region** and **txn_date**, and the business plans to add new filter columns next quarter. You need a layout that is fast today and can change later without rewriting the table by hand.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * **Small files** slow queries down because each file must be listed and opened.
# MAGIC * `OPTIMIZE` compacts small files into larger ones.
# MAGIC * **Liquid Clustering** (`CLUSTER BY (col1, col2)`) co-locates related data for data skipping. Keys can be changed later with another `ALTER TABLE ... CLUSTER BY`. `CLUSTER BY AUTO` lets Databricks choose the keys.
# MAGIC * Liquid Clustering replaces static partitioning and Z-ORDER for new tables.
# MAGIC * `DESCRIBE DETAIL` shows `numFiles` and `clusteringColumns`.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Run `DESCRIBE DETAIL lx3_fact_sales` and note `numFiles` (also stored in `lx3_baseline`).
# MAGIC 2. Enable Liquid Clustering: `ALTER TABLE lx3_fact_sales CLUSTER BY (region, txn_date)`.
# MAGIC 3. Run `OPTIMIZE lx3_fact_sales`.
# MAGIC 4. Run `DESCRIBE DETAIL` again and compare `numFiles` and `clusteringColumns`.
# MAGIC 5. Bonus: run a query filtered on `region = 'West'` and look at files read in the query profile.
# MAGIC
# MAGIC **Expected result:** `clusteringColumns` = `[region, txn_date]` and `numFiles` far below the baseline.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC DESCRIBE DETAIL lx3_fact_sales;
# MAGIC
# MAGIC ALTER TABLE lx3_fact_sales CLUSTER BY (region, txn_date);
# MAGIC OPTIMIZE lx3_fact_sales;
# MAGIC
# MAGIC DESCRIBE DETAIL lx3_fact_sales;
# MAGIC SELECT * FROM lx3_baseline;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 3.3 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 3.3: write your SQL below, then run this cell.
# MAGIC -- Step 1: DESCRIBE DETAIL lx3_fact_sales   (note numFiles)
# MAGIC -- Step 2: ALTER TABLE lx3_fact_sales CLUSTER BY (...)
# MAGIC -- Step 3: OPTIMIZE lx3_fact_sales
# MAGIC -- Step 4: DESCRIBE DETAIL lx3_fact_sales   (compare with SELECT * FROM lx3_baseline)
# MAGIC
# MAGIC SELECT 'Exercise 3.3: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 3.4 - Bridge Table and Schema Evolution
# MAGIC %md
# MAGIC ## Exercise 3.4: Bridge Table with Weights, and Schema Evolution (30 minutes)
# MAGIC
# MAGIC **Objective:** Resolve a many-to-many relationship without double counting, and evolve the fact schema safely.
# MAGIC
# MAGIC **Business scenario:** Several SKUs are in two promotions at once (for example product 1 is in both *Diwali Dhamaka* and *Buy 2 Get 1*). When marketing joins sales to promotions, those SKUs' revenue is counted twice and the campaign report is inflated. Marketing also wants a `promo_flag` column on the fact table for quick filtering.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A **bridge table** sits between a fact and a dimension in a many-to-many relationship.
# MAGIC * A **weighting factor** (`1 / number of promotions per product`) makes the weights for each product sum to 1, so allocated totals equal true totals.
# MAGIC * **Schema evolution:** `ALTER TABLE ... ADD COLUMNS` adds new nullable columns without rewriting data; existing queries keep working.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create `lx3_bridge_product_promo` (`product_key, promo_id, weight_factor`) from `lx3_promo_map`, with `weight_factor = 1.0 / COUNT(*) OVER (PARTITION BY product_key)`.
# MAGIC 2. Create view `lx3_v_promo_revenue` (`promo_id, promo_name, allocated_net_sales`) = `SUM(net_sales * weight_factor)` per promotion.
# MAGIC 3. Compare: total allocated revenue vs a naive join without weights vs true sales for promoted products.
# MAGIC 4. Add `promo_flag BOOLEAN` to `lx3_fact_sales` with `ALTER TABLE ... ADD COLUMNS`, then populate it with an `UPDATE` (true when the product appears in `lx3_promo_map`).
# MAGIC
# MAGIC **Expected result:** The weights for every product sum to 1. Total allocated revenue equals true net sales of promoted products, while the naive join is higher. `promo_flag` exists and is populated for all rows.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE TABLE lx3_bridge_product_promo AS
# MAGIC SELECT product_key, promo_id,
# MAGIC        CAST(1.0 / COUNT(*) OVER (PARTITION BY product_key) AS DECIMAL(9,6)) AS weight_factor
# MAGIC FROM lx3_promo_map;
# MAGIC
# MAGIC CREATE OR REPLACE VIEW lx3_v_promo_revenue AS
# MAGIC SELECT b.promo_id, p.promo_name, SUM(f.net_sales * b.weight_factor) AS allocated_net_sales
# MAGIC FROM lx3_fact_sales f
# MAGIC JOIN lx3_bridge_product_promo b ON f.product_key = b.product_key
# MAGIC JOIN lx3_dim_promotion p        ON b.promo_id = p.promo_id
# MAGIC GROUP BY b.promo_id, p.promo_name;
# MAGIC
# MAGIC SELECT
# MAGIC   (SELECT SUM(allocated_net_sales) FROM lx3_v_promo_revenue) AS allocated_total,
# MAGIC   (SELECT SUM(f.net_sales) FROM lx3_fact_sales f JOIN lx3_promo_map m ON f.product_key = m.product_key) AS naive_join_total,
# MAGIC   (SELECT SUM(net_sales) FROM lx3_fact_sales WHERE product_key IN (SELECT product_key FROM lx3_promo_map)) AS true_total;
# MAGIC
# MAGIC ALTER TABLE lx3_fact_sales ADD COLUMNS (promo_flag BOOLEAN COMMENT 'True when the product is part of at least one promotion');
# MAGIC UPDATE lx3_fact_sales SET promo_flag = product_key IN (SELECT product_key FROM lx3_promo_map);
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 3.4 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 3.4: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE TABLE lx3_bridge_product_promo AS SELECT product_key, promo_id, <weight_factor> FROM lx3_promo_map
# MAGIC -- Step 2: CREATE OR REPLACE VIEW lx3_v_promo_revenue AS SELECT ..., SUM(f.net_sales * b.weight_factor) AS allocated_net_sales ...
# MAGIC -- Step 3: compare allocated total vs naive join vs true total
# MAGIC -- Step 4: ALTER TABLE lx3_fact_sales ADD COLUMNS (promo_flag BOOLEAN ...); UPDATE lx3_fact_sales SET promo_flag = ...
# MAGIC
# MAGIC SELECT 'Exercise 3.4: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Self-Check Instructions
# MAGIC %md
# MAGIC ## Self-Check: Validate Your Day 3 Work (5 minutes)
# MAGIC
# MAGIC Run the next cell. It parses your bundle YAML and inspects your tables, then reports each check as **PASS** or **FAIL** with a hint.
# MAGIC
# MAGIC | Exercise | What is checked |
# MAGIC |---|---|
# MAGIC | 3.1 | Bundle name set, `catalog` variable, dev and prod targets with their own catalogs, `build_gold` depends on `load_silver`, every task uses `${var.catalog}` |
# MAGIC | 3.2 | NOT NULL on `txn_id`, the CHECK constraint, and a test table with the correct failed-row counts and statuses |
# MAGIC | 3.3 | Clustering columns set to region and txn_date, file count reduced below the baseline |
# MAGIC | 3.4 | Bridge weights sum to 1 per product, allocated revenue has no double counting, `promo_flag` added and populated |
# MAGIC
# MAGIC The 3.1 checks read the `BUNDLE_YML` variable, so run the Exercise 3.1 cell first in the same session. A score of **100%** means Day 3 is complete.

# COMMAND ----------

# DBTITLE 1,Self-Check - Run Validation
import html, yaml

LAB_DAY = "DAY 3"
CHECKS = []
def check(exercise, name, hint):
    def register(fn):
        CHECKS.append((exercise, name, hint, fn))
        return fn
    return register

def scalar(sql):
    return spark.sql(sql).collect()[0][0]

def bundle():
    if "BUNDLE_YML" not in globals():
        raise NameError("BUNDLE_YML not defined - run the Exercise 3.1 cell first")
    return yaml.safe_load(BUNDLE_YML) or {}

def job_tasks():
    jobs = (bundle().get("resources") or {}).get("jobs") or {}
    return [t for j in jobs.values() for t in (j.get("tasks") or [])]

def target_catalog(name):
    t = (bundle().get("targets") or {}).get(name) or {}
    return t, (t.get("variables") or {}).get("catalog")

# ---------------- Exercise 3.1 ----------------
@check("3.1", "Bundle name set", "Replace TODO_bundle_name, e.g. snackco_cpg_model")
def _():
    name = str((bundle().get("bundle") or {}).get("name", ""))
    return bool(name) and "TODO" not in name, f"bundle.name = {name}"

@check("3.1", "catalog variable has a default", "variables: catalog: default: dev_catalog")
def _():
    v = ((bundle().get("variables") or {}).get("catalog") or {}).get("default")
    return bool(v) and "TODO" not in str(v), f"default = {v}"

@check("3.1", "dev target: development mode, dev_catalog", "targets: dev: mode: development, variables: catalog: dev_catalog")
def _():
    t, cat = target_catalog("dev")
    ok = t.get("mode") == "development" and cat == "dev_catalog"
    return ok, f"mode = {t.get('mode')}, catalog = {cat}"

@check("3.1", "prod target: production mode, prod_catalog", "Add targets: prod: mode: production, variables: catalog: prod_catalog")
def _():
    t, cat = target_catalog("prod")
    ok = t.get("mode") == "production" and cat == "prod_catalog"
    return ok, f"mode = {t.get('mode')}, catalog = {cat}"

@check("3.1", "build_gold depends on load_silver", "Add a task build_gold with depends_on: [- task_key: load_silver]")
def _():
    tasks = {t.get("task_key"): t for t in job_tasks()}
    deps = [d.get("task_key") for d in (tasks.get("build_gold") or {}).get("depends_on") or []]
    return "load_silver" in deps, f"tasks = {list(tasks)}; build_gold depends_on = {deps}"

@check("3.1", "Every task uses ${var.catalog}", "base_parameters: catalog: ${var.catalog} in every task (no hard-coded catalogs)")
def _():
    vals = [((t.get("notebook_task") or {}).get("base_parameters") or {}).get("catalog") for t in job_tasks()]
    ok = len(vals) >= 2 and all(v == "${var.catalog}" for v in vals)
    return ok, f"catalog parameters = {vals}"

# ---------------- Exercise 3.2 ----------------
@check("3.2", "txn_id is NOT NULL", "ALTER TABLE lx3_fact_sales ALTER COLUMN txn_id SET NOT NULL")
def _():
    f = [x for x in spark.table("lx3_fact_sales").schema.fields if x.name == "txn_id"][0]
    return not f.nullable, f"txn_id nullable = {f.nullable}"

@check("3.2", "CHECK constraint chk_net_sales_non_negative", "ALTER TABLE lx3_fact_sales ADD CONSTRAINT chk_net_sales_non_negative CHECK (net_sales >= 0)")
def _():
    props = {r.key: r.value for r in spark.sql("SHOW TBLPROPERTIES lx3_fact_sales").collect()}
    v = props.get("delta.constraints.chk_net_sales_non_negative")
    return v is not None, f"constraint = {v}" if v else "Constraint not found"

@check("3.2", "Test table has the 3 checks", "Create lx3_dq_results with check_name values orphan_product_keys, duplicate_txn_ids, null_retailer_ids")
def _():
    names = {r.check_name for r in spark.sql("SELECT check_name FROM lx3_dq_results").collect()}
    want = {"orphan_product_keys", "duplicate_txn_ids", "null_retailer_ids"}
    return names == want, f"checks found: {sorted(names)}"

@check("3.2", "Failed-row counts are correct", "Orphans: LEFT ANTI JOIN to lx3_dim_product; duplicates: count txn_id values with COUNT(*) > 1; nulls: retailer_id IS NULL")
def _():
    got = {r.check_name: int(r.failed_rows) for r in spark.sql("SELECT check_name, failed_rows FROM lx3_dq_results").collect()}
    exp = {
        "orphan_product_keys": scalar("SELECT COUNT(*) FROM lx3_fact_sales f LEFT ANTI JOIN lx3_dim_product p ON f.product_key = p.product_key"),
        "duplicate_txn_ids": scalar("SELECT COUNT(*) FROM (SELECT txn_id FROM lx3_fact_sales GROUP BY txn_id HAVING COUNT(*) > 1)"),
        "null_retailer_ids": scalar("SELECT COUNT(*) FROM lx3_fact_sales WHERE retailer_id IS NULL"),
    }
    return got == exp, f"yours = {got}; expected = {exp}"

@check("3.2", "Status is PASS only when failed_rows = 0", "status = CASE WHEN failed_rows = 0 THEN 'PASS' ELSE 'FAIL' END")
def _():
    bad = scalar("SELECT COUNT(*) FROM lx3_dq_results WHERE status <> CASE WHEN failed_rows = 0 THEN 'PASS' ELSE 'FAIL' END")
    return bad == 0, f"{bad} row(s) with the wrong status"

# ---------------- Exercise 3.3 ----------------
@check("3.3", "Clustered by region and txn_date", "ALTER TABLE lx3_fact_sales CLUSTER BY (region, txn_date)")
def _():
    cols = spark.sql("DESCRIBE DETAIL lx3_fact_sales").collect()[0]["clusteringColumns"] or []
    return set(cols) == {"region", "txn_date"}, f"clusteringColumns = {cols}"

@check("3.3", "File count reduced by OPTIMIZE", "Run OPTIMIZE lx3_fact_sales after enabling clustering")
def _():
    now = spark.sql("DESCRIBE DETAIL lx3_fact_sales").collect()[0]["numFiles"]
    before = scalar("SELECT value FROM lx3_baseline WHERE metric = 'num_files_before'")
    return now < before / 4, f"{before} files before, {now} now"

# ---------------- Exercise 3.4 ----------------
@check("3.4", "Bridge weights sum to 1 per product", "weight_factor = 1.0 / COUNT(*) OVER (PARTITION BY product_key)")
def _():
    n, bad = spark.sql("""SELECT COUNT(*), COUNT_IF(ABS(w - 1) > 0.0001) FROM
        (SELECT product_key, SUM(weight_factor) AS w FROM lx3_bridge_product_promo GROUP BY product_key)""").collect()[0]
    return n == 7 and bad == 0, f"{n} products in bridge, {bad} with weights not summing to 1"

@check("3.4", "Allocated revenue has no double counting", "SUM(f.net_sales * b.weight_factor) grouped by promotion")
def _():
    a = scalar("SELECT SUM(allocated_net_sales) FROM lx3_v_promo_revenue")
    t = scalar("SELECT SUM(net_sales) FROM lx3_fact_sales WHERE product_key IN (SELECT product_key FROM lx3_promo_map)")
    return abs(float(a) - float(t)) < 1, f"allocated {float(a):,.2f} vs true {float(t):,.2f}"

@check("3.4", "promo_flag added and populated", "ALTER TABLE ... ADD COLUMNS (promo_flag BOOLEAN), then UPDATE ... SET promo_flag = ...")
def _():
    if "promo_flag" not in spark.table("lx3_fact_sales").columns:
        return False, "Column promo_flag not found"
    nulls, wrong = spark.sql("""SELECT COUNT_IF(promo_flag IS NULL),
        COUNT_IF(promo_flag <> (product_key IN (SELECT product_key FROM lx3_promo_map))) FROM lx3_fact_sales""").collect()[0]
    return nulls == 0 and wrong == 0, f"{nulls} NULL and {wrong} incorrect promo_flag values"

# ---------------- Run and report ----------------
results, by_ex = [], {}
for ex, name, hint, fn in CHECKS:
    try:
        ok, detail = fn()
    except Exception as e:
        ok, detail = False, f"{type(e).__name__}: {str(e).strip().splitlines()[0][:180]}"
    ok = bool(ok)
    results.append((ex, name, ok, detail, hint))
    by_ex.setdefault(ex, [0, 0]); by_ex[ex][0] += ok; by_ex[ex][1] += 1

passed, total = sum(r[2] for r in results), len(results)
pct = passed / total * 100
color = "#2E7D32" if pct == 100 else "#EF6C00" if pct >= 60 else "#C62828"
verdict = f"{LAB_DAY.title()} lab complete. Well done!" if pct == 100 else "Some checks failed. Use the hints below, fix, and re-run."
summary = "".join(
    f"<td style='padding:6px 14px;text-align:center;border:1px solid #CFD8DC'><b>Exercise {ex}</b><br>{p}/{t} "
    f"<span style='color:{'#2E7D32' if p == t else '#C62828'}'>{'COMPLETE' if p == t else 'INCOMPLETE'}</span></td>"
    for ex, (p, t) in by_ex.items())
rows = "".join(
    f"<tr style='background:{'#E8F5E9' if ok else '#FFEBEE'}'><td style='padding:5px 8px'>{ex}</td><td style='padding:5px 8px'>{html.escape(name)}</td>"
    f"<td style='padding:5px 8px;font-weight:bold;color:{'#2E7D32' if ok else '#C62828'}'>{'PASS' if ok else 'FAIL'}</td>"
    f"<td style='padding:5px 8px'>{html.escape(str(detail))}</td><td style='padding:5px 8px;color:#555'>{'' if ok else html.escape(hint)}</td></tr>"
    for ex, name, ok, detail, hint in results)
displayHTML(f"""<div style='font-family:Inter,Arial,sans-serif'>
<div style='background:{color};color:white;padding:14px 18px;border-radius:6px'>
<div style='font-size:14px'>{LAB_DAY} LAB SELF-CHECK | {CATALOG}.{SCHEMA}</div>
<div style='font-size:28px;font-weight:bold'>{passed} / {total} checks passed ({pct:.0f}%)</div><div>{verdict}</div></div>
<table style='border-collapse:collapse;margin:12px 0'><tr>{summary}</tr></table>
<table style='border-collapse:collapse;width:100%;font-size:13px'>
<tr style='background:#0D47A1;color:white'><th style='padding:6px'>Ex</th><th style='padding:6px'>Check</th><th style='padding:6px'>Status</th><th style='padding:6px'>Detail</th><th style='padding:6px'>Hint (if failed)</th></tr>
{rows}</table></div>""")

# COMMAND ----------

# DBTITLE 1,Day 3 Key Takeaways
# MAGIC %md
# MAGIC ## Day 3 Key Takeaways
# MAGIC
# MAGIC * **Declarative Automation Bundles** put jobs and their configuration in Git. Targets and variables remove hand edits between dev and prod.
# MAGIC * **Constraints** (NOT NULL, CHECK) stop bad data at write time; **test tables** catch what constraints cannot (orphans, duplicates) and feed the CI gate.
# MAGIC * **OPTIMIZE + Liquid Clustering** fixes small files and speeds up the filters the business uses, and the keys can evolve.
# MAGIC * **Bridge tables with weights** resolve many-to-many relationships without double counting.
# MAGIC * **Schema evolution** with `ADD COLUMNS` extends a model without breaking existing consumers.
# MAGIC
# MAGIC **Next:** Day 4 adds governance, SCD Type 2 history, a semantic layer and Genie on top of this model.