# Databricks notebook source
# DBTITLE 1,Day 4 Lab Overview
# MAGIC %md
# MAGIC # Day 4 Lab Exercises: Genie, Governance, SCD Type 2 & Semantic Layer
# MAGIC
# MAGIC Hands-on practice for Day 4 of the **Databricks Data Modelling for CPG** programme. SnackCo's model is ready for business users. You will make the Gold layer Genie-ready, secure sensitive retailer data, track retailer history with SCD Type 2, and publish a governed semantic view that reports sales correctly before and after a retailer's region change.
# MAGIC
# MAGIC | # | Exercise | Day 4 module | Time |
# MAGIC |---|---|---|---|
# MAGIC | 4.1 | Make a Gold table Genie-ready: metadata and a benchmark question set | 4.1 Genie Agent Solutions | 20 min |
# MAGIC | 4.2 | Row filters and column masks on retailer contacts | 4.2 Governance | 25 min |
# MAGIC | 4.3 | SCD Type 2 retailer dimension with MERGE | 4.2 Model Lifecycle / Capstone | 30 min |
# MAGIC | 4.4 | Point-in-time semantic view for BI and Genie | 4.2 Semantic Layer / 4.3 Capstone Review | 25 min |
# MAGIC | SC | Self-Check: automated validation of all 4 exercises | All | 5 min |
# MAGIC
# MAGIC **Total: about 105 minutes.**
# MAGIC
# MAGIC ### How to work through this lab
# MAGIC 1. Set your catalog and schema in **Lab Configuration** and run it.
# MAGIC 2. Run **Lab Setup** once. It creates the source tables and removes any earlier row filters, masks, functions and exercise objects.
# MAGIC 3. Do the exercises in order; 4.4 uses the SCD2 dimension from 4.3.
# MAGIC 4. A reference solution is folded at the end of each documentation cell.
# MAGIC 5. Run **Self-Check** at the end.
# MAGIC
# MAGIC ### Source data created by the setup
# MAGIC | Table | Description | Rows |
# MAGIC |---|---|---|
# MAGIC | `lx4_src_retailers` | Retailer master as of 1 Jan 2026 (8 retailers) | 8 |
# MAGIC | `lx4_retailer_changes` | Changes effective 1 Jul 2026: R02 moves West to **Central**, R05 rebrands to **More Megastore**, new retailer **R09** | 3 |
# MAGIC | `lx4_fact_sales` | POS sales for all of 2026 at retailer and brand level | 3,000 |
# MAGIC | `lx4_gold_sales` | Gold monthly sales by region, channel and brand (Jan-Jun 2026), with no documentation yet | 285 |
# MAGIC | `lx4_retailer_contacts` | Retailer buyer contacts with email addresses (sensitive) | 8 |

# COMMAND ----------

# DBTITLE 1,Lab Configuration
# Set your own catalog and schema here, then run this cell.
CATALOG = "lakemeter_catalog"
SCHEMA = "labuser3"

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Working in {CATALOG}.{SCHEMA}. All lab objects use the prefix lx4_")

# COMMAND ----------

# DBTITLE 1,Lab Setup - Create Source Data
# MAGIC %sql
# MAGIC -- Creates the Day 4 source tables and resets your exercise objects. Safe to re-run at any time.
# MAGIC
# MAGIC -- Reset exercise objects (tables first, so row filters and masks are released before their functions are dropped)
# MAGIC DROP VIEW     IF EXISTS lx4_v_sales_semantic;
# MAGIC DROP TABLE    IF EXISTS lx4_dim_retailer_scd2;
# MAGIC DROP TABLE    IF EXISTS lx4_genie_benchmarks;
# MAGIC DROP TABLE    IF EXISTS lx4_retailer_contacts;
# MAGIC DROP TABLE    IF EXISTS lx4_gold_sales;
# MAGIC DROP FUNCTION IF EXISTS lx4_region_filter;
# MAGIC DROP FUNCTION IF EXISTS lx4_mask_email;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx4_src_retailers AS SELECT * FROM VALUES
# MAGIC   ('R01','D-Mart Andheri','D-Mart','Modern Trade','West'),
# MAGIC   ('R02','Reliance Smart Pune','Reliance Smart','Modern Trade','West'),
# MAGIC   ('R03','Big Bazaar Saket','Big Bazaar','Modern Trade','North'),
# MAGIC   ('R04','Sharma Kirana Store','Independent','General Trade','North'),
# MAGIC   ('R05','More Koramangala','More','Modern Trade','South'),
# MAGIC   ('R06','Spencers T Nagar','Spencers','Modern Trade','South'),
# MAGIC   ('R07','Star Bazaar Salt Lake','Star Bazaar','Modern Trade','East'),
# MAGIC   ('R08','BigBasket Online','BigBasket','E-Commerce','South')
# MAGIC AS t(retailer_id, retailer_name, banner, channel, region);
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx4_retailer_changes AS SELECT * FROM VALUES
# MAGIC   ('R02','Reliance Smart Pune','Reliance Smart','Modern Trade','Central', DATE'2026-07-01'),
# MAGIC   ('R05','More Megastore Koramangala','More Megastore','Modern Trade','South', DATE'2026-07-01'),
# MAGIC   ('R09','JioMart Online','JioMart','E-Commerce','West', DATE'2026-07-01')
# MAGIC AS t(retailer_id, retailer_name, banner, channel, region, effective_date);
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx4_fact_sales AS
# MAGIC WITH g AS (SELECT id, date_add(DATE'2026-01-01', CAST(pmod(hash(id,'dt'),365) AS INT)) AS txn_date FROM range(3000))
# MAGIC SELECT CAST(id + 900000 AS BIGINT) AS txn_id, txn_date,
# MAGIC   CASE WHEN txn_date >= DATE'2026-07-01' AND pmod(hash(id,'r'),9) = 8 THEN 'R09'
# MAGIC        ELSE concat('R0', CAST(pmod(hash(id,'r'),8)+1 AS STRING)) END AS retailer_id,
# MAGIC   element_at(array('Maggi','Lays','Kurkure','Tropicana','Dove','Surf Excel','Parle-G','Amul'), pmod(hash(id,'b'),8)+1) AS brand,
# MAGIC   CAST(pmod(hash(id,'q'),20)+1 AS INT)            AS units_sold,
# MAGIC   CAST(20 + pmod(hash(id,'n'),3000) AS DECIMAL(12,2)) AS net_sales
# MAGIC FROM g;
# MAGIC
# MAGIC CREATE TABLE lx4_gold_sales AS
# MAGIC SELECT CAST(date_trunc('MONTH', f.txn_date) AS DATE) AS sales_month, r.region, r.channel, f.brand,
# MAGIC        SUM(f.net_sales) AS net_sales, SUM(f.units_sold) AS units_sold
# MAGIC FROM lx4_fact_sales f JOIN lx4_src_retailers r ON f.retailer_id = r.retailer_id
# MAGIC WHERE f.txn_date < DATE'2026-07-01'
# MAGIC GROUP BY ALL;
# MAGIC
# MAGIC CREATE TABLE lx4_retailer_contacts AS
# MAGIC SELECT retailer_id, retailer_name, region,
# MAGIC        concat(lower(replace(banner,' ','')), '.buyer', substr(retailer_id,2), '@retailmail.in') AS contact_email
# MAGIC FROM lx4_src_retailers;
# MAGIC
# MAGIC SELECT 'lx4_fact_sales' AS table_name, COUNT(*) AS row_count FROM lx4_fact_sales
# MAGIC UNION ALL SELECT 'lx4_gold_sales', COUNT(*) FROM lx4_gold_sales
# MAGIC UNION ALL SELECT 'lx4_retailer_contacts', COUNT(*) FROM lx4_retailer_contacts
# MAGIC UNION ALL SELECT 'lx4_retailer_changes', COUNT(*) FROM lx4_retailer_changes;

# COMMAND ----------

# DBTITLE 1,Exercise 4.1 - Genie-Ready Gold Table
# MAGIC %md
# MAGIC ## Exercise 4.1: Make a Gold Table Genie-Ready (20 minutes)
# MAGIC
# MAGIC **Objective:** Prepare `lx4_gold_sales` so that a Genie Space can answer business questions accurately, and define a benchmark question set to measure that accuracy.
# MAGIC
# MAGIC **Business scenario:** SnackCo's regional managers will ask a Genie Space questions such as "Which brand sold the most units in the South?". Genie relies on Unity Catalog metadata to understand tables, and the Gold table currently has none. The analytics lead also wants a small set of benchmark questions with trusted SQL, so Genie's answers can be checked before rollout.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * Genie reads **table and column comments** to map business words ("net sales", "region") to columns. Good comments are the single biggest accuracy lever, together with clear Space instructions.
# MAGIC * **Tags** classify tables for discovery and governance.
# MAGIC * **Benchmarks** pair a natural-language question with trusted SQL; Genie Spaces use them to measure answer accuracy.
# MAGIC * Genie always respects Unity Catalog permissions, row filters and masks.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Add a table comment to `lx4_gold_sales` that states its grain (one row per month x region x channel x brand).
# MAGIC 2. Add comments to **all 6 columns** (include units such as INR).
# MAGIC 3. Tag the table `quality_tier = 'gold'`.
# MAGIC 4. Create `lx4_genie_benchmarks (question STRING, expected_sql STRING)` and insert at least **3** business questions with SQL that answers them from `lx4_gold_sales`. Every SQL statement must run. Wrap each SQL string in **double quotes** so it can contain single-quoted values (in Spark SQL, doubling single quotes `''` does not escape them).
# MAGIC 5. Optional (UI): create a Genie Space on `lx4_gold_sales`, add one instruction (e.g. "Net sales are in INR"), add your benchmark questions, and try them.
# MAGIC
# MAGIC **Expected result:** The table comment, 6 column comments and the tag exist, and the benchmark table has 3 or more runnable questions.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC COMMENT ON TABLE lx4_gold_sales IS 'Gold: monthly net sales and units by region, channel and brand (Jan-Jun 2026). One row per month x region x channel x brand.';
# MAGIC ALTER TABLE lx4_gold_sales ALTER COLUMN sales_month COMMENT 'First day of the sales month';
# MAGIC ALTER TABLE lx4_gold_sales ALTER COLUMN region      COMMENT 'Sales region of the retailer: North, South, East, West';
# MAGIC ALTER TABLE lx4_gold_sales ALTER COLUMN channel     COMMENT 'Route to market: Modern Trade, General Trade, E-Commerce';
# MAGIC ALTER TABLE lx4_gold_sales ALTER COLUMN brand       COMMENT 'SnackCo brand name, e.g. Maggi, Lays, Amul';
# MAGIC ALTER TABLE lx4_gold_sales ALTER COLUMN net_sales   COMMENT 'Net sales in INR after trade discounts';
# MAGIC ALTER TABLE lx4_gold_sales ALTER COLUMN units_sold  COMMENT 'Number of units sold';
# MAGIC ALTER TABLE lx4_gold_sales SET TAGS ('quality_tier' = 'gold');
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx4_genie_benchmarks (question STRING, expected_sql STRING);
# MAGIC INSERT INTO lx4_genie_benchmarks VALUES
# MAGIC   ('What were total net sales by region in March 2026?',
# MAGIC    "SELECT region, SUM(net_sales) FROM lx4_gold_sales WHERE sales_month = DATE'2026-03-01' GROUP BY region"),
# MAGIC   ('Which brand sold the most units in the South region?',
# MAGIC    "SELECT brand, SUM(units_sold) u FROM lx4_gold_sales WHERE region = 'South' GROUP BY brand ORDER BY u DESC LIMIT 1"),
# MAGIC   ('Show the monthly E-Commerce net sales trend',
# MAGIC    "SELECT sales_month, SUM(net_sales) FROM lx4_gold_sales WHERE channel = 'E-Commerce' GROUP BY sales_month ORDER BY sales_month");
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 4.1 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 4.1: write your SQL below, then run this cell.
# MAGIC -- Step 1: COMMENT ON TABLE lx4_gold_sales IS '... grain ...'
# MAGIC -- Step 2: ALTER TABLE lx4_gold_sales ALTER COLUMN <col> COMMENT '...'   (all 6 columns)
# MAGIC -- Step 3: ALTER TABLE lx4_gold_sales SET TAGS ('quality_tier' = 'gold')
# MAGIC -- Step 4: CREATE OR REPLACE TABLE lx4_genie_benchmarks (question STRING, expected_sql STRING); INSERT INTO ... VALUES (...), (...), (...)
# MAGIC --         Tip: wrap the SQL in double quotes so it can contain single quotes: "SELECT ... WHERE region = 'South'"
# MAGIC
# MAGIC SELECT 'Exercise 4.1: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 4.2 - Row Filters and Column Masks
# MAGIC %md
# MAGIC ## Exercise 4.2: Row Filters and Column Masks (25 minutes)
# MAGIC
# MAGIC **Objective:** Enforce row-level and column-level security on sensitive retailer contact data with Unity Catalog row filters and column masks.
# MAGIC
# MAGIC **Business scenario:** `lx4_retailer_contacts` holds buyer email addresses for every retailer. Policy says: regional analysts may only see **West** region retailers, and buyer emails must be **masked** (e.g. `re****@retailmail.in`). Only members of the group `lx4_privileged_readers` see all rows and full emails. The rules must apply everywhere: SQL, dashboards and Genie.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A **row filter** is a SQL UDF that returns BOOLEAN; rows where it returns false are hidden. Attach it with `ALTER TABLE ... SET ROW FILTER fn ON (column)`.
# MAGIC * A **column mask** is a SQL UDF that returns the value to show. Attach it with `ALTER TABLE ... ALTER COLUMN col SET MASK fn`.
# MAGIC * `is_account_group_member('group')` makes the rule depend on who is querying. If the group does not exist, it returns false.
# MAGIC * Policies are listed in `information_schema.row_filters` and `information_schema.column_masks`.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create function `lx4_region_filter(region STRING) RETURNS BOOLEAN`: true for members of `lx4_privileged_readers`, otherwise only when `region = 'West'`.
# MAGIC 2. Create function `lx4_mask_email(email STRING) RETURNS STRING`: the full email for members of `lx4_privileged_readers`, otherwise the first 2 characters + `****@` + the domain.
# MAGIC 3. Attach the row filter on `region` and the mask on `contact_email`.
# MAGIC 4. Query the table. You should only see West retailers, with masked emails.
# MAGIC
# MAGIC **Expected result:** Only West rows are visible (2 retailers), every email shows `****`, and both policies are listed in `information_schema`.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE FUNCTION lx4_region_filter(region STRING) RETURNS BOOLEAN
# MAGIC   RETURN is_account_group_member('lx4_privileged_readers') OR region = 'West';
# MAGIC
# MAGIC CREATE OR REPLACE FUNCTION lx4_mask_email(email STRING) RETURNS STRING
# MAGIC   RETURN CASE WHEN is_account_group_member('lx4_privileged_readers') THEN email
# MAGIC               ELSE concat(left(email, 2), '****@', split(email, '@')[1]) END;
# MAGIC
# MAGIC ALTER TABLE lx4_retailer_contacts SET ROW FILTER lx4_region_filter ON (region);
# MAGIC ALTER TABLE lx4_retailer_contacts ALTER COLUMN contact_email SET MASK lx4_mask_email;
# MAGIC
# MAGIC SELECT * FROM lx4_retailer_contacts;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 4.2 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 4.2: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE FUNCTION lx4_region_filter(region STRING) RETURNS BOOLEAN RETURN ...
# MAGIC -- Step 2: CREATE OR REPLACE FUNCTION lx4_mask_email(email STRING) RETURNS STRING RETURN CASE WHEN ... END
# MAGIC -- Step 3: ALTER TABLE lx4_retailer_contacts SET ROW FILTER ... ON (region); ALTER TABLE ... ALTER COLUMN contact_email SET MASK ...
# MAGIC -- Step 4: SELECT * FROM lx4_retailer_contacts
# MAGIC
# MAGIC SELECT 'Exercise 4.2: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 4.3 - SCD Type 2 Dimension
# MAGIC %md
# MAGIC ## Exercise 4.3: SCD Type 2 Retailer Dimension (30 minutes)
# MAGIC
# MAGIC **Objective:** Keep the full history of retailer attributes with SCD Type 2, so facts always report against the attributes that were true on the sales date.
# MAGIC
# MAGIC **Business scenario:** On 1 July 2026, **Reliance Smart Pune (R02)** moved from the West to the new **Central** region, **More Koramangala (R05)** rebranded to **More Megastore**, and a new online retailer **JioMart (R09)** started. Finance insists that first-half sales stay in West for R02, and auditors must see exactly when each change took effect.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * SCD Type 2 adds a **new row per change**, with `effective_date`, `end_date` and `is_current`. Each version gets its own surrogate key.
# MAGIC * A common convention is `end_date = '9999-12-31'` for the current row; the expired row ends the day before the change.
# MAGIC * Pattern with Delta: (1) **MERGE** to expire the current rows that changed, (2) **INSERT** new versions for changed and brand-new natural keys.
# MAGIC * Validation rule: exactly **one current row per natural key**.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create `lx4_dim_retailer_scd2` with `retailer_key BIGINT GENERATED ALWAYS AS IDENTITY`, `retailer_id STRING NOT NULL`, `retailer_name`, `banner`, `channel`, `region`, `effective_date DATE`, `end_date DATE`, `is_current BOOLEAN`.
# MAGIC 2. Initial load from `lx4_src_retailers` with `effective_date = 2026-01-01`, `end_date = 9999-12-31`, `is_current = true`.
# MAGIC 3. MERGE `lx4_retailer_changes` on `retailer_id` and `is_current = true`: when any attribute differs, set `end_date = effective_date - 1 day` and `is_current = false`.
# MAGIC 4. INSERT the new versions: every change row that no longer has a current row in the dimension (this covers changed and new retailers).
# MAGIC 5. Query the history of R02 and R05.
# MAGIC
# MAGIC **Expected result:** 11 rows (8 initial + 2 new versions + 1 new retailer), 9 current rows (one per retailer), and R02 West ending 2026-06-30 followed by R02 Central from 2026-07-01.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE TABLE lx4_dim_retailer_scd2 (
# MAGIC   retailer_key   BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC   retailer_id    STRING NOT NULL,
# MAGIC   retailer_name  STRING,
# MAGIC   banner         STRING,
# MAGIC   channel        STRING,
# MAGIC   region         STRING,
# MAGIC   effective_date DATE,
# MAGIC   end_date       DATE,
# MAGIC   is_current     BOOLEAN);
# MAGIC
# MAGIC INSERT INTO lx4_dim_retailer_scd2 (retailer_id, retailer_name, banner, channel, region, effective_date, end_date, is_current)
# MAGIC SELECT retailer_id, retailer_name, banner, channel, region, DATE'2026-01-01', DATE'9999-12-31', true
# MAGIC FROM lx4_src_retailers;
# MAGIC
# MAGIC -- 1) Expire current rows that changed
# MAGIC MERGE INTO lx4_dim_retailer_scd2 t
# MAGIC USING lx4_retailer_changes s
# MAGIC ON t.retailer_id = s.retailer_id AND t.is_current = true
# MAGIC WHEN MATCHED AND (t.region <> s.region OR t.banner <> s.banner OR t.retailer_name <> s.retailer_name OR t.channel <> s.channel)
# MAGIC   THEN UPDATE SET t.end_date = date_sub(s.effective_date, 1), t.is_current = false;
# MAGIC
# MAGIC -- 2) Insert new versions (changed retailers) and new retailers
# MAGIC INSERT INTO lx4_dim_retailer_scd2 (retailer_id, retailer_name, banner, channel, region, effective_date, end_date, is_current)
# MAGIC SELECT s.retailer_id, s.retailer_name, s.banner, s.channel, s.region, s.effective_date, DATE'9999-12-31', true
# MAGIC FROM lx4_retailer_changes s
# MAGIC LEFT JOIN lx4_dim_retailer_scd2 t ON s.retailer_id = t.retailer_id AND t.is_current = true
# MAGIC WHERE t.retailer_id IS NULL;
# MAGIC
# MAGIC SELECT * FROM lx4_dim_retailer_scd2 WHERE retailer_id IN ('R02', 'R05') ORDER BY retailer_id, effective_date;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 4.3 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 4.3: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE TABLE lx4_dim_retailer_scd2 (retailer_key BIGINT GENERATED ALWAYS AS IDENTITY, ..., effective_date DATE, end_date DATE, is_current BOOLEAN)
# MAGIC -- Step 2: initial INSERT from lx4_src_retailers (2026-01-01 to 9999-12-31, is_current = true)
# MAGIC -- Step 3: MERGE INTO ... USING lx4_retailer_changes ... WHEN MATCHED AND (<attribute changed>) THEN UPDATE SET end_date = ..., is_current = false
# MAGIC -- Step 4: INSERT new versions for change rows that have no current row
# MAGIC -- Step 5: SELECT the history of R02 and R05
# MAGIC
# MAGIC SELECT 'Exercise 4.3: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 4.4 - Point-in-Time Semantic View
# MAGIC %md
# MAGIC ## Exercise 4.4: Point-in-Time Semantic View for BI and Genie (25 minutes)
# MAGIC
# MAGIC **Objective:** Publish a governed, business-friendly semantic view that joins facts to the SCD2 dimension **as of the sales date**.
# MAGIC
# MAGIC **Business scenario:** Dashboards and the Genie Space should not need to understand SCD2 logic. The BI team wants one documented view in which every sale carries the retailer's region and banner **valid on the day of the sale**. R02's January sales must show West, its August sales Central.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A **point-in-time join** matches the natural key **and** the date range: `f.retailer_id = d.retailer_id AND f.txn_date BETWEEN d.effective_date AND d.end_date`.
# MAGIC * Joining only on `is_current = true` would restate history (all R02 sales would show Central). That is the classic SCD2 mistake.
# MAGIC * A **semantic view** exposes business-friendly names and comments, `CREATE VIEW v (col COMMENT '...', ...) COMMENT '...' AS SELECT ...`, so BI tools and Genie can read the meaning.
# MAGIC * For reusable governed KPIs, Unity Catalog **metric views** are the next step (optional extension).
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create view `lx4_v_sales_semantic` with these columns, each with a comment: `sales_date, retailer_key, retailer_name, banner, region, brand, units_sold, net_sales_inr`, plus a view comment.
# MAGIC 2. Join `lx4_fact_sales` to `lx4_dim_retailer_scd2` with a point-in-time condition.
# MAGIC 3. Verify: the view has exactly as many rows as the fact (every sale matches exactly one version), and R02 sales split between West (before July) and Central (from July).
# MAGIC 4. Bonus: write the wrong query (join on `is_current` only) and compare R02 by region.
# MAGIC
# MAGIC **Expected result:** 3,000 rows. R02 shows West for Jan to Jun and Central for Jul to Dec; R05 shows More before July and More Megastore after.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE VIEW lx4_v_sales_semantic (
# MAGIC   sales_date    COMMENT 'Transaction date',
# MAGIC   retailer_key  COMMENT 'Surrogate key of the retailer version valid on the sales date',
# MAGIC   retailer_name COMMENT 'Retailer outlet name',
# MAGIC   banner        COMMENT 'Retail chain banner valid on the sales date',
# MAGIC   region        COMMENT 'Sales region valid on the sales date',
# MAGIC   brand         COMMENT 'SnackCo brand',
# MAGIC   units_sold    COMMENT 'Units sold',
# MAGIC   net_sales_inr COMMENT 'Net sales in INR')
# MAGIC COMMENT 'Semantic view: sales with point-in-time retailer attributes (SCD Type 2)'
# MAGIC AS SELECT f.txn_date, d.retailer_key, d.retailer_name, d.banner, d.region, f.brand, f.units_sold, f.net_sales
# MAGIC FROM lx4_fact_sales f
# MAGIC JOIN lx4_dim_retailer_scd2 d
# MAGIC   ON f.retailer_id = d.retailer_id
# MAGIC  AND f.txn_date BETWEEN d.effective_date AND d.end_date;
# MAGIC
# MAGIC SELECT region, MIN(sales_date), MAX(sales_date), COUNT(*)
# MAGIC FROM lx4_v_sales_semantic WHERE retailer_name LIKE 'Reliance%' GROUP BY region;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 4.4 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 4.4: write your SQL below, then run this cell.
# MAGIC -- Step 1-2: CREATE OR REPLACE VIEW lx4_v_sales_semantic (sales_date COMMENT '...', ...) COMMENT '...' AS SELECT ...
# MAGIC --           FROM lx4_fact_sales f JOIN lx4_dim_retailer_scd2 d ON f.retailer_id = d.retailer_id AND f.txn_date BETWEEN ... AND ...
# MAGIC -- Step 3: compare row counts with lx4_fact_sales; check R02 by region
# MAGIC
# MAGIC SELECT 'Exercise 4.4: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Self-Check Instructions
# MAGIC %md
# MAGIC ## Self-Check: Validate Your Day 4 Work (5 minutes)
# MAGIC
# MAGIC Run the next cell. It inspects metadata, policies, the SCD2 dimension and the semantic view, then reports each check as **PASS** or **FAIL** with a hint.
# MAGIC
# MAGIC | Exercise | What is checked |
# MAGIC |---|---|
# MAGIC | 4.1 | Table comment, all 6 column comments, `quality_tier` tag, 3 or more benchmark questions whose SQL runs |
# MAGIC | 4.2 | Row filter and column mask registered in `information_schema`; you see only West rows and masked emails |
# MAGIC | 4.3 | 11 rows, one current row per retailer, correct history for R02 (West to Central) and R05 (More to More Megastore) |
# MAGIC | 4.4 | Every sale matches exactly one dimension version, R02 sales split between West and Central by date, view columns documented |
# MAGIC
# MAGIC Note: if you are a member of `lx4_privileged_readers`, the 4.2 visibility checks will fail by design, because that group sees everything. A score of **100%** means Day 4, and the whole lab programme, is complete.

# COMMAND ----------

# DBTITLE 1,Self-Check - Run Validation
import html

LAB_DAY = "DAY 4"
CHECKS = []
def check(exercise, name, hint):
    def register(fn):
        CHECKS.append((exercise, name, hint, fn))
        return fn
    return register

def scalar(sql):
    return spark.sql(sql).collect()[0][0]

INFO = f"{CATALOG}.information_schema"

# ---------------- Exercise 4.1 ----------------
@check("4.1", "Gold table comment set", "COMMENT ON TABLE lx4_gold_sales IS '...' (state the grain)")
def _():
    c = scalar(f"SELECT comment FROM {INFO}.tables WHERE table_schema = '{SCHEMA}' AND table_name = 'lx4_gold_sales'")
    return bool(c), f"Comment: {c}" if c else "No table comment"

@check("4.1", "All 6 columns commented", "ALTER TABLE lx4_gold_sales ALTER COLUMN <col> COMMENT '...' for every column")
def _():
    n = scalar(f"SELECT COUNT(*) FROM {INFO}.columns WHERE table_schema = '{SCHEMA}' AND table_name = 'lx4_gold_sales' AND comment IS NOT NULL AND comment <> ''")
    return n == 6, f"{n} of 6 columns commented"

@check("4.1", "quality_tier = gold tag", "ALTER TABLE lx4_gold_sales SET TAGS ('quality_tier' = 'gold')")
def _():
    v = spark.sql(f"SELECT tag_value FROM {INFO}.table_tags WHERE schema_name = '{SCHEMA}' AND table_name = 'lx4_gold_sales' AND tag_name = 'quality_tier'").collect()
    return bool(v) and v[0][0] == "gold", f"quality_tier = {v[0][0]}" if v else "Tag not found"

@check("4.1", "3+ benchmark questions with runnable SQL", "Insert question/expected_sql pairs; wrap the SQL in double quotes so it can contain 'values'")
def _():
    rows = spark.sql("SELECT question, expected_sql FROM lx4_genie_benchmarks").collect()
    broken = []
    for r in rows:
        try:
            spark.sql(r.expected_sql).limit(1).collect()
        except Exception:
            broken.append(r.question)
    return len(rows) >= 3 and not broken, f"{len(rows)} question(s); failing SQL: {broken or 'none'}"

# ---------------- Exercise 4.2 ----------------
@check("4.2", "Row filter registered on region", "ALTER TABLE lx4_retailer_contacts SET ROW FILTER lx4_region_filter ON (region)")
def _():
    r = spark.sql(f"SELECT filter_name, target_columns FROM {INFO}.row_filters WHERE table_schema = '{SCHEMA}' AND table_name = 'lx4_retailer_contacts'").collect()
    return bool(r) and "region" in r[0][1], f"{r[0][0]} on ({r[0][1]})" if r else "No row filter found"

@check("4.2", "Column mask registered on contact_email", "ALTER TABLE lx4_retailer_contacts ALTER COLUMN contact_email SET MASK lx4_mask_email")
def _():
    r = spark.sql(f"SELECT column_name, mask_name FROM {INFO}.column_masks WHERE table_schema = '{SCHEMA}' AND table_name = 'lx4_retailer_contacts'").collect()
    ok = any(x[0] == "contact_email" for x in r)
    return ok, f"{r[0][1]} on {r[0][0]}" if r else "No column mask found"

@check("4.2", "Only West rows visible", "The filter must return true only for region = 'West' (unless privileged)")
def _():
    regions = [x[0] for x in spark.sql("SELECT DISTINCT region FROM lx4_retailer_contacts").collect()]
    return regions == ["West"], f"Visible regions: {regions}"

@check("4.2", "Emails are masked", "Return concat(left(email, 2), '****@', split(email, '@')[1]) for non-privileged users")
def _():
    n, masked = spark.sql("SELECT COUNT(*), COUNT_IF(contact_email LIKE '%****@%') FROM lx4_retailer_contacts").collect()[0]
    return n > 0 and n == masked, f"{masked} of {n} visible emails masked"

# ---------------- Exercise 4.3 ----------------
@check("4.3", "SCD2 dimension has 11 rows", "8 initial rows + 2 new versions (R02, R05) + 1 new retailer (R09)")
def _():
    n = scalar("SELECT COUNT(*) FROM lx4_dim_retailer_scd2")
    return n == 11, f"{n} rows (expected 11)"

@check("4.3", "Exactly one current row per retailer", "The MERGE must expire changed rows before the INSERT adds new versions")
def _():
    ids, bad = spark.sql("""SELECT COUNT(*), COUNT_IF(c <> 1) FROM
        (SELECT retailer_id, COUNT_IF(is_current) AS c FROM lx4_dim_retailer_scd2 GROUP BY retailer_id)""").collect()[0]
    return ids == 9 and bad == 0, f"{ids} retailers, {bad} without exactly one current row"

@check("4.3", "R02 history: West until 2026-06-30, then Central", "end_date = date_sub(effective_date, 1); new version effective 2026-07-01")
def _():
    rows = [(r.region, str(r.effective_date), str(r.end_date), r.is_current) for r in spark.sql(
        "SELECT region, effective_date, end_date, is_current FROM lx4_dim_retailer_scd2 WHERE retailer_id = 'R02' ORDER BY effective_date").collect()]
    exp = [("West", "2026-01-01", "2026-06-30", False), ("Central", "2026-07-01", "9999-12-31", True)]
    return rows == exp, f"R02 versions: {rows}"

@check("4.3", "R05 rebrand tracked (More to More Megastore)", "Compare banner and retailer_name too, not only region")
def _():
    rows = [(r.banner, r.is_current) for r in spark.sql(
        "SELECT banner, is_current FROM lx4_dim_retailer_scd2 WHERE retailer_id = 'R05' ORDER BY effective_date").collect()]
    return rows == [("More", False), ("More Megastore", True)], f"R05 versions: {rows}"

# ---------------- Exercise 4.4 ----------------
@check("4.4", "Every sale matches exactly one version", "Join on retailer_id AND txn_date BETWEEN effective_date AND end_date")
def _():
    v, f = scalar("SELECT COUNT(*) FROM lx4_v_sales_semantic"), scalar("SELECT COUNT(*) FROM lx4_fact_sales")
    return v == f, f"view {v:,} rows vs fact {f:,} rows"

@check("4.4", "R02 sales split West / Central by date", "Do not join on is_current only; that restates history")
def _():
    r = {x[0]: (str(x[1]), str(x[2])) for x in spark.sql("""SELECT region, MIN(sales_date), MAX(sales_date)
        FROM lx4_v_sales_semantic WHERE retailer_name = 'Reliance Smart Pune' GROUP BY region""").collect()}
    ok = set(r) == {"West", "Central"} and r["West"][1] < "2026-07-01" and r["Central"][0] >= "2026-07-01"
    return ok, f"R02 date ranges by region: {r}"

@check("4.4", "Net sales reconcile to the fact", "Expose the fact's net_sales as net_sales_inr")
def _():
    v, f = scalar("SELECT SUM(net_sales_inr) FROM lx4_v_sales_semantic"), scalar("SELECT SUM(net_sales) FROM lx4_fact_sales")
    return abs(float(v) - float(f)) < 0.01, f"view {float(v):,.2f} vs fact {float(f):,.2f}"

@check("4.4", "Semantic view columns documented", "CREATE VIEW lx4_v_sales_semantic (col COMMENT '...', ...) COMMENT '...' AS ...")
def _():
    n = scalar(f"SELECT COUNT(*) FROM {INFO}.columns WHERE table_schema = '{SCHEMA}' AND table_name = 'lx4_v_sales_semantic' AND comment IS NOT NULL AND comment <> ''")
    return n >= 8, f"{n} of 8 columns commented"

# ---------------- Run and report ----------------
results, by_ex = [], {}
for ex, name, hint, fn in CHECKS:
    try:
        ok, detail = fn()
    except Exception as e:
        ok, detail = False, f"{type(e).__name__}: {str(e).strip().splitlines()[0][:180]}"
    ok = bool(ok)
    results.append((ex, name, ok, detail, hint))
    by_ex.setdefault(ex, [0, 0]); by_ex[ex][0] += ok; by_ex[ex][1] += 1

passed, total = sum(r[2] for r in results), len(results)
pct = passed / total * 100
color = "#2E7D32" if pct == 100 else "#EF6C00" if pct >= 60 else "#C62828"
verdict = f"{LAB_DAY.title()} lab complete. Well done!" if pct == 100 else "Some checks failed. Use the hints below, fix, and re-run."
summary = "".join(
    f"<td style='padding:6px 14px;text-align:center;border:1px solid #CFD8DC'><b>Exercise {ex}</b><br>{p}/{t} "
    f"<span style='color:{'#2E7D32' if p == t else '#C62828'}'>{'COMPLETE' if p == t else 'INCOMPLETE'}</span></td>"
    for ex, (p, t) in by_ex.items())
rows = "".join(
    f"<tr style='background:{'#E8F5E9' if ok else '#FFEBEE'}'><td style='padding:5px 8px'>{ex}</td><td style='padding:5px 8px'>{html.escape(name)}</td>"
    f"<td style='padding:5px 8px;font-weight:bold;color:{'#2E7D32' if ok else '#C62828'}'>{'PASS' if ok else 'FAIL'}</td>"
    f"<td style='padding:5px 8px'>{html.escape(str(detail))}</td><td style='padding:5px 8px;color:#555'>{'' if ok else html.escape(hint)}</td></tr>"
    for ex, name, ok, detail, hint in results)
displayHTML(f"""<div style='font-family:Inter,Arial,sans-serif'>
<div style='background:{color};color:white;padding:14px 18px;border-radius:6px'>
<div style='font-size:14px'>{LAB_DAY} LAB SELF-CHECK | {CATALOG}.{SCHEMA}</div>
<div style='font-size:28px;font-weight:bold'>{passed} / {total} checks passed ({pct:.0f}%)</div><div>{verdict}</div></div>
<table style='border-collapse:collapse;margin:12px 0'><tr>{summary}</tr></table>
<table style='border-collapse:collapse;width:100%;font-size:13px'>
<tr style='background:#0D47A1;color:white'><th style='padding:6px'>Ex</th><th style='padding:6px'>Check</th><th style='padding:6px'>Status</th><th style='padding:6px'>Detail</th><th style='padding:6px'>Hint (if failed)</th></tr>
{rows}</table></div>""")

# COMMAND ----------

# DBTITLE 1,Day 4 Key Takeaways
# MAGIC %md
# MAGIC ## Day 4 Key Takeaways
# MAGIC
# MAGIC * **Metadata is the interface for Genie.** Comments, tags and benchmark questions decide how well business users' questions are answered.
# MAGIC * **Row filters and column masks** enforce security once, in Unity Catalog, for SQL, dashboards and Genie alike.
# MAGIC * **SCD Type 2** keeps every version of a dimension row; expire then insert, and always validate one current row per natural key.
# MAGIC * **Point-in-time joins** (natural key + date range) give correct historical reporting; joining on `is_current` restates history.
# MAGIC * A documented **semantic view** hides modelling complexity from BI tools and Genie, and is the stepping stone to metric views.
# MAGIC
# MAGIC **Programme complete:** you have built and governed a full CPG Sales & Distribution model, from Bronze to Genie.