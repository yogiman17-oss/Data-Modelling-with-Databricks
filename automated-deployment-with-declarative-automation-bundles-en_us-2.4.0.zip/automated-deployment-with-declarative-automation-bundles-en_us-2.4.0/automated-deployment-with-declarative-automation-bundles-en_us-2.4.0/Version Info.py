# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Project Information
# MAGIC
# MAGIC * Name: **Automated Deployment with Declarative Automation Bundles**
# MAGIC * Version:  **unspecified**
# MAGIC * Built On: **14 October 2026 14:07:22**

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Copyrights
# MAGIC This section documents the various copyrights as they relate to the datasets used in this course.
# MAGIC  
# MAGIC Run the following cell for additional information on this course's datasets, and their copyrights.

# COMMAND ----------

# MAGIC %run ./Includes/Print-Dataset-Copyrights

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>