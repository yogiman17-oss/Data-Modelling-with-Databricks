# Databricks notebook source
# DBTITLE 1,Day 2 Lab Overview
# MAGIC %md
# MAGIC # Day 2 Lab Exercises: Dimensional Modelling, Fact Tables & Medallion
# MAGIC
# MAGIC Hands-on practice for Day 2 of the **Databricks Data Modelling for CPG** programme. As SnackCo's data modeller, you will turn raw POS, product, retailer and inventory feeds into a **star schema** with conformed dimensions, two fact types, and a Gold aggregate for the sales and supply-chain teams.
# MAGIC
# MAGIC | # | Exercise | Day 2 module | Time |
# MAGIC |---|---|---|---|
# MAGIC | 2.1 | Build a date dimension with an Indian fiscal calendar | 2.1 Dimensional Fundamentals | 20 min |
# MAGIC | 2.2 | Product and retailer dimensions with surrogate keys | 2.2 Building CPG Dimension Tables | 25 min |
# MAGIC | 2.3 | Transaction fact table: fact_sales | 2.3 CPG Fact Tables & Loading | 25 min |
# MAGIC | 2.4 | Periodic snapshot fact and a Gold aggregate (semi-additive stock) | 2.3 Facts / 2.4 Medallion | 30 min |
# MAGIC | SC | Self-Check: automated validation of all 4 exercises | All | 5 min |
# MAGIC
# MAGIC **Total: about 105 minutes.**
# MAGIC
# MAGIC ### How to work through this lab
# MAGIC 1. Set your catalog and schema in **Lab Configuration** and run it.
# MAGIC 2. Run **Lab Setup** once. It creates the source tables (`lx2_src_*`) and resets your exercise tables.
# MAGIC 3. Work through the exercises in order, because each one builds on the previous one.
# MAGIC 4. Write your SQL in the **Your Work** cell after each documentation cell. A reference solution is folded at the end of each documentation cell.
# MAGIC 5. Run **Self-Check** at the end.
# MAGIC
# MAGIC ### Target star schema
# MAGIC
# MAGIC ```
# MAGIC                  lx2_dim_date
# MAGIC                       |
# MAGIC lx2_dim_product --- lx2_fact_sales --- lx2_dim_retailer
# MAGIC       |
# MAGIC lx2_fact_inventory_snapshot ---> lx2_gold_monthly_brand (Gold)
# MAGIC ```
# MAGIC
# MAGIC ### Source data created by the setup
# MAGIC | Table | Grain | Rows |
# MAGIC |---|---|---|
# MAGIC | `lx2_src_products` | One row per SKU (12 SKUs, 8 brands) | 12 |
# MAGIC | `lx2_src_retailers` | One row per retail outlet (8 outlets, 4 regions, 3 channels) | 8 |
# MAGIC | `lx2_src_sales` | One row per POS transaction, Jan to Jun 2026 | 3,000 |
# MAGIC | `lx2_src_inventory` | Stock on hand per day, SKU and warehouse (2 warehouses) | 4,344 |

# COMMAND ----------

# DBTITLE 1,Lab Configuration
# Set your own catalog and schema here, then run this cell.
CATALOG = "lakemeter_catalog"
SCHEMA = "labuser3"

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Working in {CATALOG}.{SCHEMA}. All lab objects use the prefix lx2_")

# COMMAND ----------

# DBTITLE 1,Lab Setup - Create Source Data
# MAGIC %sql
# MAGIC -- Creates the Day 2 source tables and resets your exercise tables. Safe to re-run at any time.
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx2_src_products AS SELECT * FROM VALUES
# MAGIC   ('SKU001','Maggi Masala 70g','Maggi','Noodles','70g',14.0),       ('SKU002','Maggi Masala 280g','Maggi','Noodles','280g',52.0),
# MAGIC   ('SKU003','Lays Classic 52g','Lays','Snacks','52g',20.0),         ('SKU004','Lays Magic Masala 90g','Lays','Snacks','90g',30.0),
# MAGIC   ('SKU005','Kurkure Masala 90g','Kurkure','Snacks','90g',20.0),    ('SKU006','Tropicana Orange 1L','Tropicana','Beverages','1L',110.0),
# MAGIC   ('SKU007','Tropicana Apple 200ml','Tropicana','Beverages','200ml',25.0), ('SKU008','Dove Soap 100g','Dove','Personal Care','100g',60.0),
# MAGIC   ('SKU009','Surf Excel 1kg','Surf Excel','Home Care','1kg',140.0), ('SKU010','Parle-G 250g','Parle-G','Biscuits','250g',25.0),
# MAGIC   ('SKU011','Amul Butter 100g','Amul','Dairy','100g',58.0),         ('SKU012','Amul Cheese 200g','Amul','Dairy','200g',135.0)
# MAGIC AS t(sku, product_name, brand, category, pack_size, list_price);
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx2_src_retailers AS SELECT * FROM VALUES
# MAGIC   ('R01','D-Mart Andheri','D-Mart','Modern Trade','Mumbai','West'),
# MAGIC   ('R02','Reliance Smart Pune','Reliance Smart','Modern Trade','Pune','West'),
# MAGIC   ('R03','Big Bazaar Saket','Big Bazaar','Modern Trade','Delhi','North'),
# MAGIC   ('R04','Sharma Kirana Store','Independent','General Trade','Lucknow','North'),
# MAGIC   ('R05','More Koramangala','More','Modern Trade','Bengaluru','South'),
# MAGIC   ('R06','Spencers T Nagar','Spencers','Modern Trade','Chennai','South'),
# MAGIC   ('R07','Star Bazaar Salt Lake','Star Bazaar','Modern Trade','Kolkata','East'),
# MAGIC   ('R08','BigBasket Online','BigBasket','E-Commerce','Bengaluru','South')
# MAGIC AS t(retailer_id, retailer_name, banner, channel, city, region);
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx2_src_sales AS
# MAGIC WITH g AS (
# MAGIC   SELECT id,
# MAGIC     concat('SKU', lpad(CAST(pmod(hash(id,'s'),12)+1 AS STRING),3,'0')) AS sku,
# MAGIC     concat('R0', CAST(pmod(hash(id,'r'),8)+1 AS STRING))                AS retailer_id,
# MAGIC     pmod(hash(id,'q'),20)+1 AS qty,
# MAGIC     pmod(hash(id,'d'),12)   AS disc_pct
# MAGIC   FROM range(3000))
# MAGIC SELECT CAST(g.id + 500000 AS BIGINT) AS txn_id,
# MAGIC        date_add(DATE'2026-01-01', CAST(pmod(hash(g.id,'dt'),181) AS INT)) AS txn_date,
# MAGIC        g.sku, g.retailer_id, CAST(g.qty AS INT) AS qty, p.list_price AS unit_price,
# MAGIC        ROUND(g.qty * p.list_price * g.disc_pct / 100, 2) AS discount_amt
# MAGIC FROM g JOIN lx2_src_products p ON g.sku = p.sku;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx2_src_inventory AS
# MAGIC SELECT d AS snapshot_date, p.sku, w.warehouse,
# MAGIC        CAST(500 + pmod(hash(d, p.sku, w.warehouse), 1500) AS INT) AS qty_on_hand
# MAGIC FROM (SELECT explode(sequence(DATE'2026-01-01', DATE'2026-06-30', INTERVAL 1 DAY)) AS d)
# MAGIC CROSS JOIN lx2_src_products p
# MAGIC CROSS JOIN (SELECT explode(array('WH-Mumbai','WH-Delhi')) AS warehouse) w;
# MAGIC
# MAGIC -- Reset exercise tables
# MAGIC DROP TABLE IF EXISTS lx2_dim_date;
# MAGIC DROP TABLE IF EXISTS lx2_dim_product;
# MAGIC DROP TABLE IF EXISTS lx2_dim_retailer;
# MAGIC DROP TABLE IF EXISTS lx2_fact_sales;
# MAGIC DROP TABLE IF EXISTS lx2_fact_inventory_snapshot;
# MAGIC DROP TABLE IF EXISTS lx2_gold_monthly_brand;
# MAGIC
# MAGIC SELECT 'lx2_src_products' AS table_name, COUNT(*) AS row_count FROM lx2_src_products
# MAGIC UNION ALL SELECT 'lx2_src_retailers', COUNT(*) FROM lx2_src_retailers
# MAGIC UNION ALL SELECT 'lx2_src_sales', COUNT(*) FROM lx2_src_sales
# MAGIC UNION ALL SELECT 'lx2_src_inventory', COUNT(*) FROM lx2_src_inventory;

# COMMAND ----------

# DBTITLE 1,Exercise 2.1 - Date Dimension with Fiscal Calendar
# MAGIC %md
# MAGIC ## Exercise 2.1: Date Dimension with an Indian Fiscal Calendar (20 minutes)
# MAGIC
# MAGIC **Objective:** Build a conformed `dim_date` that supports both calendar and fiscal reporting.
# MAGIC
# MAGIC **Business scenario:** SnackCo's finance team reports on the Indian fiscal year, which runs **1 April to 31 March** and is named after the year in which it ends (April 2026 to March 2027 = **FY2027**). Sales teams report by calendar month. Both must use the same date dimension so their numbers always reconcile.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A date dimension has **one row per day** and a smart integer key `date_key` in `yyyyMMdd` format (e.g. `20260401`).
# MAGIC * It is **role-playing**: the same table can serve order date, ship date or snapshot date.
# MAGIC * Fiscal attributes are computed columns, not a separate table.
# MAGIC * `sequence(start, end, INTERVAL 1 DAY)` with `explode()` generates the day rows.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create `lx2_dim_date` for every day of **2026** (365 rows) with these columns: `date_key` (INT), `full_date`, `calendar_year`, `calendar_quarter`, `calendar_month`, `month_name`, `week_of_year`, `day_name`, `is_weekend`, `fiscal_year`, `fiscal_quarter`.
# MAGIC 2. Fiscal rules: `fiscal_year` = year + 1 for April to December, otherwise year. `fiscal_quarter`: Apr-Jun = 1, Jul-Sep = 2, Oct-Dec = 3, Jan-Mar = 4.
# MAGIC 3. Verify the dates 2026-01-15, 2026-04-01 and 2026-01-03 (a Saturday).
# MAGIC
# MAGIC **Expected result:** 365 unique `date_key` values. 2026-04-01 is FY2027 Q1, 2026-01-15 is FY2026 Q4, and 2026-01-03 has `is_weekend = true`.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE TABLE lx2_dim_date AS
# MAGIC SELECT
# MAGIC   CAST(date_format(d, 'yyyyMMdd') AS INT) AS date_key,
# MAGIC   d                                       AS full_date,
# MAGIC   year(d)                                 AS calendar_year,
# MAGIC   quarter(d)                              AS calendar_quarter,
# MAGIC   month(d)                                AS calendar_month,
# MAGIC   date_format(d, 'MMMM')                  AS month_name,
# MAGIC   weekofyear(d)                           AS week_of_year,
# MAGIC   date_format(d, 'EEEE')                  AS day_name,
# MAGIC   dayofweek(d) IN (1, 7)                  AS is_weekend,
# MAGIC   CASE WHEN month(d) >= 4 THEN year(d) + 1 ELSE year(d) END AS fiscal_year,
# MAGIC   CASE WHEN month(d) BETWEEN 4 AND 6  THEN 1
# MAGIC        WHEN month(d) BETWEEN 7 AND 9  THEN 2
# MAGIC        WHEN month(d) BETWEEN 10 AND 12 THEN 3
# MAGIC        ELSE 4 END                         AS fiscal_quarter
# MAGIC FROM (SELECT explode(sequence(DATE'2026-01-01', DATE'2026-12-31', INTERVAL 1 DAY)) AS d);
# MAGIC
# MAGIC SELECT * FROM lx2_dim_date WHERE date_key IN (20260103, 20260115, 20260401);
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 2.1 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 2.1: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE TABLE lx2_dim_date AS SELECT CAST(date_format(d,'yyyyMMdd') AS INT) AS date_key, ...
# MAGIC --         FROM (SELECT explode(sequence(DATE'2026-01-01', DATE'2026-12-31', INTERVAL 1 DAY)) AS d)
# MAGIC -- Step 2: add fiscal_year and fiscal_quarter with CASE expressions
# MAGIC -- Step 3: SELECT * FROM lx2_dim_date WHERE date_key IN (20260103, 20260115, 20260401)
# MAGIC
# MAGIC SELECT 'Exercise 2.1: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 2.2 - Dimensions with Surrogate Keys
# MAGIC %md
# MAGIC ## Exercise 2.2: Product and Retailer Dimensions with Surrogate Keys (25 minutes)
# MAGIC
# MAGIC **Objective:** Create dimension tables whose primary keys are system-generated **surrogate keys**, keeping source codes as **natural keys**.
# MAGIC
# MAGIC **Business scenario:** SKU codes come from SAP, retailer codes from the distributor management system, and both have been reformatted before. SnackCo wants stable warehouse keys that never change when a source system does, and that will later support SCD Type 2 history.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A **surrogate key** is a meaningless integer owned by the warehouse; the **natural key** (`sku`, `retailer_id`) stays as an attribute.
# MAGIC * Delta generates surrogate keys with `BIGINT GENERATED ALWAYS AS IDENTITY`.
# MAGIC * With an identity column you must **list the columns** in `INSERT INTO table (col1, col2, ...)` and leave out the key.
# MAGIC * Natural keys should be `NOT NULL`.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create `lx2_dim_product` with `product_key BIGINT GENERATED ALWAYS AS IDENTITY`, `sku STRING NOT NULL`, `product_name`, `brand`, `category`, `pack_size`, `list_price DECIMAL(10,2)`.
# MAGIC 2. Load it from `lx2_src_products` with `INSERT INTO ... (column list) SELECT ...`.
# MAGIC 3. Create and load `lx2_dim_retailer` the same way: `retailer_key` identity, `retailer_id STRING NOT NULL`, `retailer_name`, `banner`, `channel`, `city`, `region`.
# MAGIC 4. Verify with `SHOW CREATE TABLE` that the keys are identity columns, and that every key is unique.
# MAGIC
# MAGIC **Expected result:** `lx2_dim_product` has 12 rows and `lx2_dim_retailer` has 8, each with unique, automatically generated keys.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE TABLE lx2_dim_product (
# MAGIC   product_key  BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC   sku          STRING NOT NULL,
# MAGIC   product_name STRING,
# MAGIC   brand        STRING,
# MAGIC   category     STRING,
# MAGIC   pack_size    STRING,
# MAGIC   list_price   DECIMAL(10,2));
# MAGIC
# MAGIC INSERT INTO lx2_dim_product (sku, product_name, brand, category, pack_size, list_price)
# MAGIC SELECT sku, product_name, brand, category, pack_size, list_price FROM lx2_src_products;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx2_dim_retailer (
# MAGIC   retailer_key  BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC   retailer_id   STRING NOT NULL,
# MAGIC   retailer_name STRING,
# MAGIC   banner        STRING,
# MAGIC   channel       STRING,
# MAGIC   city          STRING,
# MAGIC   region        STRING);
# MAGIC
# MAGIC INSERT INTO lx2_dim_retailer (retailer_id, retailer_name, banner, channel, city, region)
# MAGIC SELECT retailer_id, retailer_name, banner, channel, city, region FROM lx2_src_retailers;
# MAGIC
# MAGIC SHOW CREATE TABLE lx2_dim_product;
# MAGIC SELECT * FROM lx2_dim_retailer ORDER BY retailer_key;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 2.2 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 2.2: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE TABLE lx2_dim_product (product_key BIGINT GENERATED ALWAYS AS IDENTITY, sku STRING NOT NULL, ...)
# MAGIC -- Step 2: INSERT INTO lx2_dim_product (sku, product_name, ...) SELECT ... FROM lx2_src_products
# MAGIC -- Step 3: same pattern for lx2_dim_retailer from lx2_src_retailers
# MAGIC -- Step 4: SHOW CREATE TABLE lx2_dim_product
# MAGIC
# MAGIC SELECT 'Exercise 2.2: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 2.3 - Transaction Fact Table
# MAGIC %md
# MAGIC ## Exercise 2.3: Transaction Fact Table - lx2_fact_sales (25 minutes)
# MAGIC
# MAGIC **Objective:** Build a transaction-grain fact table that references dimensions through surrogate keys and carries additive measures.
# MAGIC
# MAGIC **Business scenario:** Regional sales managers want to slice SnackCo's sales by day, brand, retailer, banner, channel and region. The fact table must have exactly **one row per POS transaction**, reconcile to the source to the rupee, and join to every dimension without gaps.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * **Declare the grain first:** one row per `txn_id`.
# MAGIC * Replace natural keys with **surrogate keys** by joining to the dimensions (`sku` to `product_key`, `retailer_id` to `retailer_key`).
# MAGIC * Derive `date_key` as `CAST(date_format(txn_date, 'yyyyMMdd') AS INT)`.
# MAGIC * Measures: `quantity_sold`, `gross_sales = qty * unit_price`, `discount_amt`, `net_sales = gross_sales - discount_amt`. All are fully **additive**.
# MAGIC * `txn_id` stays in the fact as a **degenerate dimension**.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create `lx2_fact_sales` with columns `date_key, product_key, retailer_key, txn_id, quantity_sold, unit_price, gross_sales, discount_amt, net_sales`.
# MAGIC 2. Check the row count against `lx2_src_sales` (no rows lost or duplicated by the joins).
# MAGIC 3. Check that every `date_key` exists in `lx2_dim_date` (a `LEFT ANTI JOIN` should return 0 rows).
# MAGIC 4. Reconcile total `net_sales` to the source.
# MAGIC
# MAGIC **Expected result:** 3,000 rows, no NULL foreign keys, no orphan dates, and net sales equal to the source total.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE TABLE lx2_fact_sales AS
# MAGIC SELECT
# MAGIC   CAST(date_format(s.txn_date, 'yyyyMMdd') AS INT)            AS date_key,
# MAGIC   p.product_key,
# MAGIC   r.retailer_key,
# MAGIC   s.txn_id,
# MAGIC   s.qty                                                      AS quantity_sold,
# MAGIC   s.unit_price,
# MAGIC   CAST(s.qty * s.unit_price AS DECIMAL(12,2))                AS gross_sales,
# MAGIC   s.discount_amt,
# MAGIC   CAST(s.qty * s.unit_price - s.discount_amt AS DECIMAL(12,2)) AS net_sales
# MAGIC FROM lx2_src_sales s
# MAGIC JOIN lx2_dim_product  p ON s.sku = p.sku
# MAGIC JOIN lx2_dim_retailer r ON s.retailer_id = r.retailer_id;
# MAGIC
# MAGIC SELECT COUNT(*) FROM lx2_fact_sales;
# MAGIC SELECT COUNT(*) AS orphan_dates FROM lx2_fact_sales f LEFT ANTI JOIN lx2_dim_date d ON f.date_key = d.date_key;
# MAGIC SELECT (SELECT SUM(net_sales) FROM lx2_fact_sales) AS fact_net,
# MAGIC        (SELECT SUM(qty * unit_price - discount_amt) FROM lx2_src_sales) AS source_net;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 2.3 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 2.3: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE TABLE lx2_fact_sales AS SELECT <date_key>, p.product_key, r.retailer_key, s.txn_id, <measures>
# MAGIC --         FROM lx2_src_sales s JOIN lx2_dim_product p ON ... JOIN lx2_dim_retailer r ON ...
# MAGIC -- Step 2-4: row count, orphan dates with LEFT ANTI JOIN, net sales reconciliation
# MAGIC
# MAGIC SELECT 'Exercise 2.3: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Exercise 2.4 - Periodic Snapshot and Gold Aggregate
# MAGIC %md
# MAGIC ## Exercise 2.4: Periodic Snapshot Fact and a Gold Aggregate (30 minutes)
# MAGIC
# MAGIC **Objective:** Model daily stock as a **periodic snapshot** fact, then publish a Gold table that aggregates an additive measure (sales) and a **semi-additive** measure (stock) correctly.
# MAGIC
# MAGIC **Business scenario:** The supply-chain finance team wants one monthly table by brand showing net sales, units sold and **month-end stock on hand**. Last quarter someone summed 30 daily snapshots and reported stock 30 times too high. Your Gold table must not repeat that mistake.
# MAGIC
# MAGIC **Concepts recap**
# MAGIC * A **periodic snapshot** has one row per period (day), product and location, even when nothing moved.
# MAGIC * `qty_on_hand` is **semi-additive**: you can sum it across products and warehouses, but **not across time**. For a month, take the value on the **last snapshot date** (or the average).
# MAGIC * Gold tables are business-ready aggregates built from Silver facts and dimensions.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Create `lx2_fact_inventory_snapshot` (`date_key, product_key, warehouse, qty_on_hand`) from `lx2_src_inventory`, joined to `lx2_dim_product`.
# MAGIC 2. Create `lx2_gold_monthly_brand` with columns `calendar_month, brand, net_sales, units_sold, month_end_stock`:
# MAGIC    * `net_sales` and `units_sold`: SUM from `lx2_fact_sales` by month and brand.
# MAGIC    * `month_end_stock`: SUM of `qty_on_hand` across warehouses and SKUs **on the last snapshot date of each month only**.
# MAGIC 3. Reconcile Gold `net_sales` to `lx2_fact_sales`, and compare `month_end_stock` with a naive SUM over the whole month to see the difference.
# MAGIC
# MAGIC **Expected result:** 4,344 snapshot rows and 48 Gold rows (8 brands x 6 months). Gold net sales match the fact, and `month_end_stock` equals the stock on the 31st/30th of each month.
# MAGIC
# MAGIC <details><summary><b>Reference solution (open only if stuck)</b></summary>
# MAGIC
# MAGIC ```sql
# MAGIC CREATE OR REPLACE TABLE lx2_fact_inventory_snapshot AS
# MAGIC SELECT CAST(date_format(i.snapshot_date, 'yyyyMMdd') AS INT) AS date_key,
# MAGIC        p.product_key, i.warehouse, i.qty_on_hand
# MAGIC FROM lx2_src_inventory i JOIN lx2_dim_product p ON i.sku = p.sku;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE lx2_gold_monthly_brand AS
# MAGIC WITH sales AS (
# MAGIC   SELECT d.calendar_month, p.brand, SUM(f.net_sales) AS net_sales, SUM(f.quantity_sold) AS units_sold
# MAGIC   FROM lx2_fact_sales f
# MAGIC   JOIN lx2_dim_date d    ON f.date_key = d.date_key
# MAGIC   JOIN lx2_dim_product p ON f.product_key = p.product_key
# MAGIC   GROUP BY d.calendar_month, p.brand),
# MAGIC month_end AS (
# MAGIC   SELECT d.calendar_month, MAX(f.date_key) AS last_date_key
# MAGIC   FROM lx2_fact_inventory_snapshot f JOIN lx2_dim_date d ON f.date_key = d.date_key
# MAGIC   GROUP BY d.calendar_month),
# MAGIC stock AS (
# MAGIC   SELECT m.calendar_month, p.brand, SUM(f.qty_on_hand) AS month_end_stock
# MAGIC   FROM lx2_fact_inventory_snapshot f
# MAGIC   JOIN month_end m       ON f.date_key = m.last_date_key
# MAGIC   JOIN lx2_dim_product p ON f.product_key = p.product_key
# MAGIC   GROUP BY m.calendar_month, p.brand)
# MAGIC SELECT s.calendar_month, s.brand, s.net_sales, s.units_sold, st.month_end_stock
# MAGIC FROM sales s LEFT JOIN stock st ON s.calendar_month = st.calendar_month AND s.brand = st.brand;
# MAGIC
# MAGIC SELECT * FROM lx2_gold_monthly_brand ORDER BY calendar_month, brand;
# MAGIC ```
# MAGIC </details>

# COMMAND ----------

# DBTITLE 1,Exercise 2.4 - Your Work
# MAGIC %sql
# MAGIC -- Exercise 2.4: write your SQL below, then run this cell.
# MAGIC -- Step 1: CREATE OR REPLACE TABLE lx2_fact_inventory_snapshot AS SELECT <date_key>, p.product_key, i.warehouse, i.qty_on_hand FROM ...
# MAGIC -- Step 2: CREATE OR REPLACE TABLE lx2_gold_monthly_brand AS WITH sales AS (...), month_end AS (...), stock AS (...) SELECT ...
# MAGIC -- Step 3: reconcile net_sales and compare month_end_stock vs a naive monthly SUM
# MAGIC
# MAGIC SELECT 'Exercise 2.4: add your SQL above this line' AS status;

# COMMAND ----------

# DBTITLE 1,Self-Check Instructions
# MAGIC %md
# MAGIC ## Self-Check: Validate Your Day 2 Work (5 minutes)
# MAGIC
# MAGIC Run the next cell. It inspects your star schema and reports each check as **PASS** or **FAIL** with a hint.
# MAGIC
# MAGIC | Exercise | What is checked |
# MAGIC |---|---|
# MAGIC | 2.1 | 365 unique date keys, fiscal year and quarter rules, weekend flag |
# MAGIC | 2.2 | Identity surrogate keys on both dimensions, row counts, unique keys |
# MAGIC | 2.3 | 3,000 rows, no NULL foreign keys, no orphan dates, net sales reconcile to source |
# MAGIC | 2.4 | 4,344 snapshot rows, 48 Gold rows, Gold net sales reconcile, month-end stock is semi-additive (not summed over the month) |
# MAGIC
# MAGIC Fix any FAIL, re-run that exercise, then run the Self-Check again. A score of **100%** means Day 2 is complete.

# COMMAND ----------

# DBTITLE 1,Self-Check - Run Validation
import html

LAB_DAY = "DAY 2"
CHECKS = []
def check(exercise, name, hint):
    def register(fn):
        CHECKS.append((exercise, name, hint, fn))
        return fn
    return register

def scalar(sql):
    return spark.sql(sql).collect()[0][0]

# ---------------- Exercise 2.1 ----------------
@check("2.1", "365 unique date keys for 2026", "Generate days with explode(sequence(DATE'2026-01-01', DATE'2026-12-31', INTERVAL 1 DAY))")
def _():
    n, d = spark.sql("SELECT COUNT(*), COUNT(DISTINCT date_key) FROM lx2_dim_date").collect()[0]
    return n == 365 and d == 365, f"{n} rows, {d} distinct date_key"

@check("2.1", "2026-04-01 is FY2027 Q1", "fiscal_year = year + 1 from April; fiscal_quarter 1 = Apr-Jun")
def _():
    r = spark.sql("SELECT fiscal_year, fiscal_quarter FROM lx2_dim_date WHERE date_key = 20260401").collect()[0]
    return (r[0], r[1]) == (2027, 1), f"fiscal_year={r[0]}, fiscal_quarter={r[1]}"

@check("2.1", "2026-01-15 is FY2026 Q4", "January to March belong to fiscal quarter 4 of the fiscal year ending that March")
def _():
    r = spark.sql("SELECT fiscal_year, fiscal_quarter FROM lx2_dim_date WHERE date_key = 20260115").collect()[0]
    return (r[0], r[1]) == (2026, 4), f"fiscal_year={r[0]}, fiscal_quarter={r[1]}"

@check("2.1", "Weekend flag correct (2026-01-03 is Saturday)", "is_weekend = dayofweek(d) IN (1, 7)")
def _():
    v = scalar("SELECT is_weekend FROM lx2_dim_date WHERE date_key = 20260103")
    return v is True, f"is_weekend = {v}"

# ---------------- Exercise 2.2 ----------------
@check("2.2", "product_key is an IDENTITY column", "product_key BIGINT GENERATED ALWAYS AS IDENTITY")
def _():
    ddl = scalar("SHOW CREATE TABLE lx2_dim_product")
    ok = "product_key BIGINT GENERATED" in ddl and "AS IDENTITY" in ddl
    return ok, "Identity column found" if ok else "product_key is not an identity column"

@check("2.2", "retailer_key is an IDENTITY column", "retailer_key BIGINT GENERATED ALWAYS AS IDENTITY")
def _():
    ddl = scalar("SHOW CREATE TABLE lx2_dim_retailer")
    ok = "retailer_key BIGINT GENERATED" in ddl and "AS IDENTITY" in ddl
    return ok, "Identity column found" if ok else "retailer_key is not an identity column"

@check("2.2", "Dimension row counts (12 products, 8 retailers)", "INSERT INTO ... (column list) SELECT ... FROM the lx2_src_ tables, once only")
def _():
    p, r = scalar("SELECT COUNT(*) FROM lx2_dim_product"), scalar("SELECT COUNT(*) FROM lx2_dim_retailer")
    return (p, r) == (12, 8), f"{p} products, {r} retailers"

@check("2.2", "Surrogate and natural keys unique", "Recreate the table if you inserted the data twice")
def _():
    a = spark.sql("SELECT COUNT(DISTINCT product_key), COUNT(DISTINCT sku), COUNT(*) FROM lx2_dim_product").collect()[0]
    b = spark.sql("SELECT COUNT(DISTINCT retailer_key), COUNT(DISTINCT retailer_id), COUNT(*) FROM lx2_dim_retailer").collect()[0]
    ok = len(set(a)) == 1 and len(set(b)) == 1
    return ok, f"product keys/skus/rows = {tuple(a)}; retailer keys/ids/rows = {tuple(b)}"

# ---------------- Exercise 2.3 ----------------
@check("2.3", "lx2_fact_sales has 3,000 rows (one per txn_id)", "Use inner joins on the natural keys; do not join on columns that multiply rows")
def _():
    n, d = spark.sql("SELECT COUNT(*), COUNT(DISTINCT txn_id) FROM lx2_fact_sales").collect()[0]
    return n == 3000 and d == 3000, f"{n:,} rows, {d:,} distinct txn_id"

@check("2.3", "No NULL foreign keys", "Every row needs date_key, product_key and retailer_key")
def _():
    n = scalar("SELECT COUNT(*) FROM lx2_fact_sales WHERE date_key IS NULL OR product_key IS NULL OR retailer_key IS NULL")
    return n == 0, f"{n} row(s) with NULL keys"

@check("2.3", "No orphan date keys", "date_key = CAST(date_format(txn_date, 'yyyyMMdd') AS INT)")
def _():
    n = scalar("SELECT COUNT(*) FROM lx2_fact_sales f LEFT ANTI JOIN lx2_dim_date d ON f.date_key = d.date_key")
    return n == 0, f"{n} orphan date_key value(s)"

@check("2.3", "Net sales reconcile to source", "net_sales = qty * unit_price - discount_amt")
def _():
    f = scalar("SELECT SUM(net_sales) FROM lx2_fact_sales")
    s = scalar("SELECT SUM(qty * unit_price - discount_amt) FROM lx2_src_sales")
    return abs(float(f) - float(s)) < 0.01, f"fact {float(f):,.2f} vs source {float(s):,.2f}"

# ---------------- Exercise 2.4 ----------------
@check("2.4", "Snapshot fact has 4,344 rows", "One row per day x SKU x warehouse from lx2_src_inventory")
def _():
    n = scalar("SELECT COUNT(*) FROM lx2_fact_inventory_snapshot")
    return n == 4344, f"{n:,} rows (expected 4,344)"

@check("2.4", "Gold table has 48 rows (8 brands x 6 months)", "GROUP BY calendar_month, brand")
def _():
    n = scalar("SELECT COUNT(*) FROM lx2_gold_monthly_brand")
    return n == 48, f"{n} rows (expected 48)"

@check("2.4", "Gold net sales reconcile to the fact", "SUM(f.net_sales) joined through dim_date and dim_product")
def _():
    g, f = scalar("SELECT SUM(net_sales) FROM lx2_gold_monthly_brand"), scalar("SELECT SUM(net_sales) FROM lx2_fact_sales")
    return abs(float(g) - float(f)) < 0.01, f"gold {float(g):,.2f} vs fact {float(f):,.2f}"

@check("2.4", "month_end_stock uses the last snapshot date only", "Stock is semi-additive: filter to MAX(date_key) per month before summing")
def _():
    bad = scalar("""
        WITH me AS (SELECT CAST(date_format(MAX(snapshot_date), 'M') AS INT) AS m, MAX(snapshot_date) AS d FROM lx2_src_inventory GROUP BY month(snapshot_date)),
        exp AS (SELECT me.m AS calendar_month, p.brand, SUM(i.qty_on_hand) AS stock
                FROM lx2_src_inventory i JOIN me ON i.snapshot_date = me.d JOIN lx2_src_products p ON i.sku = p.sku GROUP BY me.m, p.brand)
        SELECT COUNT(*) FROM exp e LEFT JOIN lx2_gold_monthly_brand g ON e.calendar_month = g.calendar_month AND e.brand = g.brand
        WHERE g.month_end_stock IS NULL OR g.month_end_stock <> e.stock""")
    return bad == 0, "All 48 month-end values correct" if bad == 0 else f"{bad} brand-month(s) have the wrong month_end_stock"

# ---------------- Run and report ----------------
results, by_ex = [], {}
for ex, name, hint, fn in CHECKS:
    try:
        ok, detail = fn()
    except Exception as e:
        ok, detail = False, f"{type(e).__name__}: {str(e).strip().splitlines()[0][:180]}"
    ok = bool(ok)
    results.append((ex, name, ok, detail, hint))
    by_ex.setdefault(ex, [0, 0]); by_ex[ex][0] += ok; by_ex[ex][1] += 1

passed, total = sum(r[2] for r in results), len(results)
pct = passed / total * 100
color = "#2E7D32" if pct == 100 else "#EF6C00" if pct >= 60 else "#C62828"
verdict = f"{LAB_DAY.title()} lab complete. Well done!" if pct == 100 else "Some checks failed. Use the hints below, fix, and re-run."
summary = "".join(
    f"<td style='padding:6px 14px;text-align:center;border:1px solid #CFD8DC'><b>Exercise {ex}</b><br>{p}/{t} "
    f"<span style='color:{'#2E7D32' if p == t else '#C62828'}'>{'COMPLETE' if p == t else 'INCOMPLETE'}</span></td>"
    for ex, (p, t) in by_ex.items())
rows = "".join(
    f"<tr style='background:{'#E8F5E9' if ok else '#FFEBEE'}'><td style='padding:5px 8px'>{ex}</td><td style='padding:5px 8px'>{html.escape(name)}</td>"
    f"<td style='padding:5px 8px;font-weight:bold;color:{'#2E7D32' if ok else '#C62828'}'>{'PASS' if ok else 'FAIL'}</td>"
    f"<td style='padding:5px 8px'>{html.escape(str(detail))}</td><td style='padding:5px 8px;color:#555'>{'' if ok else html.escape(hint)}</td></tr>"
    for ex, name, ok, detail, hint in results)
displayHTML(f"""<div style='font-family:Inter,Arial,sans-serif'>
<div style='background:{color};color:white;padding:14px 18px;border-radius:6px'>
<div style='font-size:14px'>{LAB_DAY} LAB SELF-CHECK | {CATALOG}.{SCHEMA}</div>
<div style='font-size:28px;font-weight:bold'>{passed} / {total} checks passed ({pct:.0f}%)</div><div>{verdict}</div></div>
<table style='border-collapse:collapse;margin:12px 0'><tr>{summary}</tr></table>
<table style='border-collapse:collapse;width:100%;font-size:13px'>
<tr style='background:#0D47A1;color:white'><th style='padding:6px'>Ex</th><th style='padding:6px'>Check</th><th style='padding:6px'>Status</th><th style='padding:6px'>Detail</th><th style='padding:6px'>Hint (if failed)</th></tr>
{rows}</table></div>""")

# COMMAND ----------

# DBTITLE 1,Day 2 Key Takeaways
# MAGIC %md
# MAGIC ## Day 2 Key Takeaways
# MAGIC
# MAGIC * A **conformed date dimension** with fiscal attributes lets finance and sales report from one source of truth.
# MAGIC * **Surrogate keys** (`GENERATED ALWAYS AS IDENTITY`) separate the warehouse from source-system codes and enable SCD history.
# MAGIC * **Declare the grain** before building a fact, then reconcile row counts and totals to the source.
# MAGIC * **Semi-additive measures** such as stock on hand must never be summed across time; use the period-end (or average) value.
# MAGIC * Gold aggregates turn the star schema into business-ready tables for dashboards and Genie.
# MAGIC
# MAGIC **Next:** Day 3 adds DevOps, performance optimization and data quality on top of this model.